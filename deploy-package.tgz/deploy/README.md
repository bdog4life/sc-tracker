# SC Tracker — DigitalOcean Deployment

Moves the SC Tracker server from Replit Autoscale onto a $4/mo DigitalOcean
Ubuntu droplet. The Replit-managed PostgreSQL database stays in place — the
droplet just connects to it remotely.

---

## Prerequisites

- A DigitalOcean Ubuntu 22.04 or 24.04 droplet (any size, 1 GB RAM is fine)
- Your GitHub repo URL for this project
- SSH access to the droplet (`ssh root@<droplet-ip>`)
- The values from your Replit Secrets tab (DATABASE_URL, Discord keys, etc.)

---

## Step 1 — Point DNS at the droplet

In your DNS provider, update the **A record** for `tracker.noharmsc.org` to
the droplet's public IP address. Leave TTL low (60s) while migrating.

> Do this **before** running setup so Let's Encrypt can verify the domain.

---

## Step 2 — SSH into the droplet and run setup

```bash
ssh root@<droplet-ip>

# Clone the repo first (or the setup script will ask for the URL)
git clone https://github.com/YOUR_ORG/YOUR_REPO /home/sctracker/app

# Run the setup script
bash /home/sctracker/app/deploy/setup.sh
```

The script will:
- Install Node.js 20, PM2, nginx, certbot
- Build the TypeScript server
- Create `/home/sctracker/.sc-tracker.env` from the template
- Configure nginx with WebSocket + SSE support
- Obtain a Let's Encrypt SSL certificate
- Register PM2 to start on boot

---

## Step 3 — Fill in environment variables

```bash
nano /home/sctracker/.sc-tracker.env
```

Copy each value from the Replit Secrets tab:

| Variable | Where to find it |
|----------|-----------------|
| `DATABASE_URL` | Replit → Secrets tab (runtime-managed) |
| `DISCORD_CLIENT_ID` | Replit → Secrets tab |
| `DISCORD_CLIENT_SECRET` | Replit → Secrets tab |
| `JWT_SECRET` | Replit → Secrets tab |
| `SESSION_SECRET` | Replit → Secrets tab |

`DISCORD_REDIRECT_URI` stays the same — the domain doesn't change.

---

## Step 4 — Start the app

```bash
sudo -u sctracker pm2 restart sc-tracker
sudo -u sctracker pm2 logs sc-tracker
```

Verify you see:
```
[migrate] sc_tracker schema ready
[seed] Replit DB already has data — skipping seed
[server] Listening on port 3000
```

---

## Step 5 — Unpublish from Replit

Once `https://tracker.noharmsc.org` is loading from the droplet:

1. Open this Replit project
2. Click **Publish** → **Unpublish** (or **Manage** → remove deployment)
3. The Replit Postgres database stays active — it's not tied to the deployment

---

## Updating the app

```bash
ssh root@<droplet-ip>
sudo -u sctracker bash -c "
  cd /home/sctracker/app &&
  git pull &&
  cd server && npm install --omit=dev &&
  npm run build &&
  pm2 restart sc-tracker
"
```

Or use the helper script:

```bash
bash /home/sctracker/app/deploy/update.sh
```

---

## Useful commands

```bash
# App logs (live)
sudo -u sctracker pm2 logs sc-tracker

# Restart
sudo -u sctracker pm2 restart sc-tracker

# nginx logs
tail -f /var/log/nginx/error.log
tail -f /var/log/nginx/access.log

# SSL cert renewal (runs automatically via systemd timer)
certbot renew --dry-run
```
