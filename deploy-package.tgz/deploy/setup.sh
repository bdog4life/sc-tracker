#!/usr/bin/env bash
# =============================================================================
# SC Tracker — DigitalOcean Ubuntu setup script
# Run once as root (or with sudo) on a fresh Ubuntu 22.04/24.04 droplet.
#
# Usage:
#   curl -fsSL https://raw.githubusercontent.com/YOUR_ORG/YOUR_REPO/main/deploy/setup.sh | bash
#   -- or --
#   bash deploy/setup.sh
# =============================================================================
set -euo pipefail

APP_USER="sctracker"
APP_DIR="/home/${APP_USER}/app"
DOMAIN="tracker.noharmsc.org"
NODE_VERSION="20"

echo "==> Updating system packages"
apt-get update -qq && apt-get upgrade -y -qq

echo "==> Installing system dependencies"
apt-get install -y -qq curl git nginx certbot python3-certbot-nginx ufw

# ---------------------------------------------------------------------------
# Node.js via NodeSource
# ---------------------------------------------------------------------------
echo "==> Installing Node.js ${NODE_VERSION}"
curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
apt-get install -y nodejs
node -v && npm -v

echo "==> Installing PM2"
npm install -g pm2

# ---------------------------------------------------------------------------
# Firewall
# ---------------------------------------------------------------------------
echo "==> Configuring UFW firewall"
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable

# ---------------------------------------------------------------------------
# App user
# ---------------------------------------------------------------------------
echo "==> Creating app user: ${APP_USER}"
id -u "${APP_USER}" &>/dev/null || useradd -m -s /bin/bash "${APP_USER}"

# ---------------------------------------------------------------------------
# Clone / update repo
# ---------------------------------------------------------------------------
echo "==> Cloning repository into ${APP_DIR}"
if [ -d "${APP_DIR}/.git" ]; then
  echo "    Repo exists — pulling latest"
  sudo -u "${APP_USER}" git -C "${APP_DIR}" pull
else
  read -rp "GitHub repo URL (e.g. https://github.com/you/sc-tracker): " REPO_URL
  sudo -u "${APP_USER}" git clone "${REPO_URL}" "${APP_DIR}"
fi

# ---------------------------------------------------------------------------
# Install deps & build
# ---------------------------------------------------------------------------
echo "==> Installing npm dependencies"
sudo -u "${APP_USER}" bash -c "cd ${APP_DIR}/server && npm install --omit=dev"
sudo -u "${APP_USER}" bash -c "cd ${APP_DIR}/server && npm install --save-dev typescript tsx"

echo "==> Building TypeScript"
sudo -u "${APP_USER}" bash -c "cd ${APP_DIR}/server && npm run build"

# ---------------------------------------------------------------------------
# Environment file
# ---------------------------------------------------------------------------
ENV_FILE="/home/${APP_USER}/.sc-tracker.env"
if [ ! -f "${ENV_FILE}" ]; then
  echo "==> Creating env file at ${ENV_FILE}"
  cp "${APP_DIR}/deploy/env.template" "${ENV_FILE}"
  chmod 600 "${ENV_FILE}"
  chown "${APP_USER}:${APP_USER}" "${ENV_FILE}"
  echo ""
  echo "  *** IMPORTANT: Edit ${ENV_FILE} and fill in all values before starting PM2 ***"
  echo "  Run: nano ${ENV_FILE}"
else
  echo "==> Env file already exists — skipping"
fi

# ---------------------------------------------------------------------------
# PM2
# ---------------------------------------------------------------------------
echo "==> Configuring PM2"
sudo -u "${APP_USER}" bash -c "cd ${APP_DIR} && pm2 start deploy/ecosystem.config.js"
sudo -u "${APP_USER}" pm2 save
env PATH=$PATH:/usr/bin pm2 startup systemd -u "${APP_USER}" --hp "/home/${APP_USER}" | tail -1 | bash

# ---------------------------------------------------------------------------
# Nginx
# ---------------------------------------------------------------------------
echo "==> Configuring nginx"
cp "${APP_DIR}/deploy/nginx.conf" "/etc/nginx/sites-available/${DOMAIN}"
ln -sf "/etc/nginx/sites-available/${DOMAIN}" "/etc/nginx/sites-enabled/${DOMAIN}"
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

# ---------------------------------------------------------------------------
# SSL via Let's Encrypt
# ---------------------------------------------------------------------------
echo "==> Obtaining SSL certificate (make sure DNS is already pointed at this server)"
read -rp "Proceed with SSL cert for ${DOMAIN}? [y/N]: " DO_SSL
if [[ "${DO_SSL,,}" == "y" ]]; then
  read -rp "Admin email for Let's Encrypt: " LE_EMAIL
  certbot --nginx -d "${DOMAIN}" --non-interactive --agree-tos -m "${LE_EMAIL}"
  systemctl enable --now certbot.timer
fi

echo ""
echo "==> Setup complete!"
echo "    1. Edit env vars:  nano ${ENV_FILE}"
echo "    2. Restart app:    sudo -u ${APP_USER} pm2 restart sc-tracker"
echo "    3. Watch logs:     sudo -u ${APP_USER} pm2 logs sc-tracker"
