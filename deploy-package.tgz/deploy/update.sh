#!/usr/bin/env bash
# SC Tracker — deploy update script
# Run on the droplet to pull latest code and restart.
# Usage: bash /home/sctracker/app/deploy/update.sh

set -euo pipefail

APP_DIR="/home/sctracker/app"
APP_USER="sctracker"

echo "==> Pulling latest code"
sudo -u "${APP_USER}" git -C "${APP_DIR}" pull

echo "==> Installing dependencies"
sudo -u "${APP_USER}" bash -c "cd ${APP_DIR}/server && npm install --omit=dev"

echo "==> Building TypeScript"
sudo -u "${APP_USER}" bash -c "cd ${APP_DIR}/server && npm run build"

echo "==> Restarting PM2"
sudo -u "${APP_USER}" pm2 restart sc-tracker

echo "==> Done — watching logs (Ctrl+C to exit)"
sudo -u "${APP_USER}" pm2 logs sc-tracker --lines 30
