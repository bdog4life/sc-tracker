// PM2 process config for SC Tracker
// Docs: https://pm2.keymetrics.io/docs/usage/application-declaration/

module.exports = {
  apps: [
    {
      name: 'sc-tracker',
      script: 'server/dist/server/src/main.js',
      cwd: '/home/sctracker/app',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '400M',
      env_file: '/home/sctracker/.sc-tracker.env',
      env: {
        NODE_ENV: 'production',
        PORT: '3000',
      },
      error_file: '/home/sctracker/logs/sc-tracker-error.log',
      out_file:   '/home/sctracker/logs/sc-tracker-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
    },
  ],
};
