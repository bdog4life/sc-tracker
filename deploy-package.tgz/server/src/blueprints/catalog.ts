export interface CatalogEntry {
  blueprint_id: string;
  name: string;
  category: string;
  loc_key: string;
}

let cache: CatalogEntry[] | null = null;
let cacheTime = 0;
const TTL_MS = 24 * 60 * 60 * 1000;

export async function getBlueprintCatalog(): Promise<CatalogEntry[]> {
  if (cache && Date.now() - cacheTime < TTL_MS) return cache;
  try {
    const resp = await fetch('https://sc-craft.tools/api/blueprints');
    if (resp.ok) {
      const data = await resp.json() as { items: CatalogEntry[] };
      cache = data.items;
      cacheTime = Date.now();
      console.log(`[blueprints] Loaded ${cache.length} entries from sc-craft.tools`);
    }
  } catch (err) {
    console.warn('[blueprints] Failed to fetch sc-craft.tools catalog:', err);
  }
  return cache ?? [];
}

export function matchCatalog(rawName: string, catalog: CatalogEntry[]): CatalogEntry | null {
  const ourKey = rawName.replace(/^@item_Name_/i, '').toLowerCase();
  for (const entry of catalog) {
    const theirKey = entry.loc_key.replace(/^item_name_?/i, '').toLowerCase();
    if (ourKey === theirKey) return entry;
  }
  return null;
}

export function prettifyRawName(rawName: string): string {
  return rawName
    .replace(/^@item_Name_/i, '')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, c => c.toUpperCase())
    .trim();
}
