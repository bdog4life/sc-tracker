import { EventEmitter } from 'events';
import { Response } from 'express';

export interface LiveFeedEvent {
  type: 'session_start' | 'highlight' | 'contract' | 'mission';
  username: string;
  discordId: string;
  avatar: string;
  message: string;
  icon: string;
  severity?: string;
  sessionId?: number;
  ts: number;
}

class LiveBroadcaster extends EventEmitter {
  private clients = new Set<Response>();

  addClient(res: Response): void {
    this.clients.add(res);
    res.on('close', () => this.clients.delete(res));
  }

  broadcast(event: LiveFeedEvent): void {
    const data = `data: ${JSON.stringify(event)}\n\n`;
    for (const res of this.clients) {
      try { res.write(data); } catch { this.clients.delete(res); }
    }
  }

  get size(): number { return this.clients.size; }
}

export const liveBroadcaster = new LiveBroadcaster();
liveBroadcaster.setMaxListeners(0);
