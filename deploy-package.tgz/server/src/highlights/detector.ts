// server/src/highlights/detector.ts
// "Interesting events" engine — detects noteworthy moments from raw events
// and writes them to sc_tracker.highlights.
//
// Two entry points:
//   detectHighlightsForEvent  — runs on every event ingested
//   detectHighlightsForSession — runs on SESSION_END
//
// Each detector is idempotent via the (user_id, type, dedup_key) UNIQUE.

import * as https from 'https';
import { Pool, PoolClient } from 'pg';
import { ParsedEvent } from '../../../shared/types';

export type Severity = 'epic' | 'major' | 'minor' | 'info';

export interface HighlightRow {
  type: string;
  severity: Severity;
  occurredAt: Date;
  sessionId: number | null;
  payload: Record<string, unknown>;
  dedupKey: string;
}

type Querier = Pool | PoolClient;

// ── Webhook display helper ───────────────────────────────────────────────────

export function webhookDisplay(type: string, payload: Record<string, unknown>): { icon: string; title: string; desc: string } {
  switch (type) {
    case 'FIRST_ZONE':           return { icon: '📍', title: 'New Zone Discovered',   desc: `First time visiting "${payload['zoneName']}"` };
    case 'RARE_SHIP':            return { icon: '🛸', title: 'Rare Ship Spotted',      desc: `First ever sighting of ${payload['shipClass']}` };
    case 'COMEBACK':             return { icon: '🔄', title: 'Welcome Back!',          desc: `Back after ${payload['gapDays']} days away` };
    case 'MARATHON':             return { icon: '⏱️', title: 'Marathon Session',       desc: `Played for ${Math.floor(Number(payload['durationSecs'] ?? 0) / 3600)}h` };
    case 'MISSION_STREAK':       return { icon: '🎯', title: 'Mission Streak',         desc: `${payload['contracts']} contracts in one session` };
    case 'BLUEPRINT_HAUL':       return { icon: '📋', title: 'Blueprint Haul',         desc: `${payload['blueprints']} blueprints collected` };
    case 'SHIP_LOSS_RECOVERY':   return { icon: '💥', title: 'Ship Loss Recovery',     desc: `Kept flying 30+ min after losing a ship` };
    case 'PERSONAL_BEST_SESSION':return { icon: '🏆', title: 'Personal Best!',         desc: `New record in: ${((payload['categories'] as string[]) || []).join(', ')}` };
    case 'BIG_DAY':              return { icon: '🌟', title: 'Big Day!',               desc: `6+ hours logged today` };
    case 'SERVER_HOPPER':        return { icon: '🔀', title: 'Server Hopper',          desc: `3+ session starts in 10 minutes` };
    default:                     return { icon: '⭐', title: type,                     desc: '' };
  }
}

// ── Webhook sender ───────────────────────────────────────────────────────────

async function sendWebhookIfConfigured(db: Querier, userId: number, h: HighlightRow): Promise<void> {
  try {
    const urlRow = await db.query<{ discord_webhook_url: string | null }>(
      `SELECT discord_webhook_url FROM sc_tracker.users WHERE id = $1`,
      [userId]
    );
    const webhookUrl = urlRow.rows[0]?.discord_webhook_url;
    if (!webhookUrl) return;

    const { icon, title, desc } = webhookDisplay(h.type, h.payload);
    const colorMap: Record<string, number> = { epic: 0x8B5CF6, major: 0x3B82F6, minor: 0x10B981, info: 0x94A3B8 };
    const color = colorMap[h.severity] ?? 0x3B82F6;

    const body = JSON.stringify({
      embeds: [{
        title: `${icon} ${title}`,
        description: desc || undefined,
        color,
        timestamp: h.occurredAt.toISOString(),
        footer: { text: 'SC Tracker · sc-tracker.replit.app' },
      }],
    });

    const url = new URL(webhookUrl);
    await new Promise<void>((resolve) => {
      const req = https.request({
        hostname: url.hostname,
        path: url.pathname + url.search,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      }, (res) => { res.resume(); res.on('end', resolve); res.on('error', () => resolve()); });
      req.on('error', () => resolve());
      req.setTimeout(5000, () => { req.destroy(); resolve(); });
      req.write(body);
      req.end();
    });
  } catch { /* best-effort — never crash the highlight path */ }
}

// ── Insert helper ────────────────────────────────────────────────────────────

async function insertHighlight(db: Querier, userId: number, h: HighlightRow): Promise<boolean> {
  const result = await db.query(
    `INSERT INTO sc_tracker.highlights
       (user_id, session_id, type, severity, occurred_at, payload, dedup_key)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     ON CONFLICT (user_id, type, dedup_key) DO NOTHING
     RETURNING id`,
    [userId, h.sessionId, h.type, h.severity, h.occurredAt, JSON.stringify(h.payload), h.dedupKey]
  );
  const inserted = (result.rowCount ?? 0) > 0;
  if (inserted && (h.severity === 'epic' || h.severity === 'major')) {
    sendWebhookIfConfigured(db, userId, h).catch(() => {});
  }
  return inserted;
}

// ── Per-event detectors ──────────────────────────────────────────────────────

export async function detectHighlightsForEvent(
  db: Querier,
  userId: number,
  sessionId: number | null,
  event: ParsedEvent
): Promise<HighlightRow[]> {
  const written: HighlightRow[] = [];

  // FIRST_ZONE — the first time this user has entered a given zone name.
  if (event.type === 'ZONE_ENTERED') {
    const text = String(event.payload['notificationText'] ?? '').trim();
    if (!text) return written;
    const zoneName = text.replace(/:\s*$/, '');
    const prior = await db.query<{ id: number }>(
      `SELECT id FROM sc_tracker.events
       WHERE user_id = $1 AND event_type = 'ZONE_ENTERED'
         AND payload->>'notificationText' = $2
         AND occurred_at < $3
       LIMIT 1`,
      [userId, text, event.occurredAt]
    );
    if (prior.rows.length === 0) {
      const h: HighlightRow = {
        type: 'FIRST_ZONE', severity: 'minor', occurredAt: event.occurredAt,
        sessionId, payload: { zoneName }, dedupKey: zoneName.toLowerCase(),
      };
      if (await insertHighlight(db, userId, h)) written.push(h);
    }
    return written;
  }

  // RARE_SHIP — first time a particular ship class has appeared globally.
  if (event.type === 'SHIP_NEARBY') {
    const shipClass = String(event.payload['shipClass'] ?? '').trim();
    if (!shipClass) return written;
    const prior = await db.query<{ id: number }>(
      `SELECT id FROM sc_tracker.events
       WHERE event_type = 'SHIP_NEARBY'
         AND payload->>'shipClass' = $1
         AND occurred_at < $2
       LIMIT 1`,
      [shipClass, event.occurredAt]
    );
    if (prior.rows.length === 0) {
      const h: HighlightRow = {
        type: 'RARE_SHIP', severity: 'major', occurredAt: event.occurredAt,
        sessionId, payload: { shipClass }, dedupKey: shipClass.toLowerCase(),
      };
      if (await insertHighlight(db, userId, h)) written.push(h);
    }
    return written;
  }

  // SESSION_START detectors — comeback + server hopper
  if (event.type === 'SESSION_START' && sessionId !== null) {
    const prev = await db.query<{ started_at: Date }>(
      `SELECT started_at FROM sc_tracker.sessions
       WHERE user_id = $1 AND id <> $2
       ORDER BY started_at DESC
       LIMIT 1`,
      [userId, sessionId]
    );
    if (prev.rows[0]) {
      const gapMs = event.occurredAt.getTime() - new Date(prev.rows[0].started_at).getTime();
      const gapDays = gapMs / (1000 * 60 * 60 * 24);
      if (gapDays >= 7) {
        const h: HighlightRow = {
          type: 'COMEBACK', severity: 'major', occurredAt: event.occurredAt,
          sessionId, payload: { gapDays: Math.round(gapDays) }, dedupKey: String(sessionId),
        };
        if (await insertHighlight(db, userId, h)) written.push(h);
      }
    }

    const recent = await db.query<{ cnt: string }>(
      `SELECT COUNT(*) AS cnt FROM sc_tracker.sessions
       WHERE user_id = $1 AND started_at >= $2`,
      [userId, new Date(event.occurredAt.getTime() - 10 * 60 * 1000)]
    );
    if (parseInt(recent.rows[0]?.cnt ?? '0', 10) >= 3) {
      const h: HighlightRow = {
        type: 'SERVER_HOPPER', severity: 'info', occurredAt: event.occurredAt,
        sessionId, payload: {}, dedupKey: String(sessionId),
      };
      if (await insertHighlight(db, userId, h)) written.push(h);
    }
    return written;
  }

  return written;
}

// ── Per-session detectors (run on SESSION_END) ───────────────────────────────

export async function detectHighlightsForSession(
  db: Querier,
  userId: number,
  sessionId: number
): Promise<HighlightRow[]> {
  const written: HighlightRow[] = [];

  const sessionRow = await db.query<{
    started_at: Date; ended_at: Date | null; duration_secs: number | null;
  }>(
    `SELECT started_at, ended_at, duration_secs FROM sc_tracker.sessions WHERE id = $1`,
    [sessionId]
  );
  const s = sessionRow.rows[0];
  if (!s) return written;
  const durationSecs = s.duration_secs ?? 0;
  const occurredAt = s.ended_at ?? new Date();

  const counts = await db.query<{ event_type: string; cnt: string }>(
    `SELECT event_type, COUNT(*) AS cnt FROM sc_tracker.events WHERE session_id = $1 GROUP BY event_type`,
    [sessionId]
  );
  const c = new Map<string, number>();
  for (const r of counts.rows) c.set(r.event_type, parseInt(r.cnt, 10));

  const missions  = c.get('MISSION_START') ?? 0;
  const contracts = c.get('CONTRACT_COMPLETE') ?? 0;
  const blueprints = c.get('BLUEPRINT_RECEIVED') ?? 0;
  const shipClaims = c.get('SHIP_CLAIM') ?? 0;

  if (durationSecs >= 4 * 3600) {
    const h: HighlightRow = { type: 'MARATHON', severity: 'major', occurredAt, sessionId, payload: { durationSecs }, dedupKey: String(sessionId) };
    if (await insertHighlight(db, userId, h)) written.push(h);
  }

  if (contracts >= 5) {
    const h: HighlightRow = { type: 'MISSION_STREAK', severity: 'major', occurredAt, sessionId, payload: { contracts }, dedupKey: String(sessionId) };
    if (await insertHighlight(db, userId, h)) written.push(h);
  }

  if (blueprints >= 2) {
    const h: HighlightRow = { type: 'BLUEPRINT_HAUL', severity: 'major', occurredAt, sessionId, payload: { blueprints }, dedupKey: String(sessionId) };
    if (await insertHighlight(db, userId, h)) written.push(h);
  }

  if (shipClaims >= 1) {
    const claim = await db.query<{ first_claim: Date }>(
      `SELECT MIN(occurred_at) AS first_claim FROM sc_tracker.events WHERE session_id = $1 AND event_type = 'SHIP_CLAIM'`,
      [sessionId]
    );
    const firstClaim = claim.rows[0]?.first_claim;
    if (firstClaim && occurredAt.getTime() - new Date(firstClaim).getTime() >= 30 * 60 * 1000) {
      const h: HighlightRow = { type: 'SHIP_LOSS_RECOVERY', severity: 'minor', occurredAt, sessionId, payload: { shipClaims }, dedupKey: String(sessionId) };
      if (await insertHighlight(db, userId, h)) written.push(h);
    }
  }

  const priorMax = await db.query<{ max_missions: string | null; max_contracts: string | null; max_duration: string | null }>(
    `SELECT
       MAX( (SELECT COUNT(*) FROM sc_tracker.events e WHERE e.session_id = s.id AND e.event_type = 'MISSION_START') ) AS max_missions,
       MAX( (SELECT COUNT(*) FROM sc_tracker.events e WHERE e.session_id = s.id AND e.event_type = 'CONTRACT_COMPLETE') ) AS max_contracts,
       MAX(s.duration_secs) AS max_duration
     FROM sc_tracker.sessions s WHERE s.user_id = $1 AND s.id <> $2`,
    [userId, sessionId]
  );
  const pm = priorMax.rows[0];
  const beatMissions  = missions > 0 && missions > parseInt(pm?.max_missions ?? '0', 10);
  const beatContracts = contracts > 0 && contracts > parseInt(pm?.max_contracts ?? '0', 10);
  const beatDuration  = durationSecs > 0 && durationSecs > parseInt(pm?.max_duration ?? '0', 10);
  if (beatMissions || beatContracts || beatDuration) {
    const categories: string[] = [];
    if (beatMissions) categories.push('missions');
    if (beatContracts) categories.push('contracts');
    if (beatDuration) categories.push('playtime');
    const h: HighlightRow = { type: 'PERSONAL_BEST_SESSION', severity: 'major', occurredAt, sessionId, payload: { categories, missions, contracts, durationSecs }, dedupKey: String(sessionId) };
    if (await insertHighlight(db, userId, h)) written.push(h);
  }

  const dayWindow = await db.query<{ total: string | null }>(
    `SELECT COALESCE(SUM(duration_secs), 0) AS total
     FROM sc_tracker.sessions
     WHERE user_id = $1 AND ended_at IS NOT NULL
       AND ended_at >= $2 AND ended_at <= $3`,
    [userId, new Date(occurredAt.getTime() - 24 * 60 * 60 * 1000), occurredAt]
  );
  const todayTotal = parseInt(dayWindow.rows[0]?.total ?? '0', 10);
  if (todayTotal >= 6 * 3600) {
    const dayKey = occurredAt.toISOString().slice(0, 10);
    const h: HighlightRow = { type: 'BIG_DAY', severity: 'minor', occurredAt, sessionId, payload: { totalSecs: todayTotal }, dedupKey: dayKey };
    if (await insertHighlight(db, userId, h)) written.push(h);
  }

  return written;
}
