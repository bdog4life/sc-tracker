import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import { migrate } from './db/migrate';
import { seedFromNeon } from './db/seedFromNeon';
import { pool } from './db/client';
import { getBlueprintCatalog, matchCatalog } from './blueprints/catalog';
import { authRouter } from './routes/auth';
import { trackerRouter } from './routes/tracker';
import { dashboardRouter } from './routes/dashboard';
import { sessionMiddleware } from './middleware/session';
import { authLimiter, apiLimiter, dashboardLimiter } from './middleware/ratelimit';
import { banCheck } from './middleware/security';

const PORT = parseInt(process.env['PORT'] ?? '3000', 10);

const REQUIRED_ENV = ['SESSION_SECRET', 'JWT_SECRET', 'DISCORD_CLIENT_ID', 'DISCORD_CLIENT_SECRET'];
for (const key of REQUIRED_ENV) {
  if (!process.env[key]) throw new Error(`Missing required env var: ${key}`);
}
if (!process.env['DATABASE_URL']) {
  throw new Error('Missing required env var: DATABASE_URL');
}

/** Seal orphaned sessions — fill duration_secs + ended_at from last event. */
async function sealOrphanedSessions(): Promise<void> {
  try {
    const result = await pool.query(`
      WITH open_sessions AS (
        SELECT id, started_at FROM sc_tracker.sessions
        WHERE duration_secs IS NULL AND started_at < NOW() - INTERVAL '5 minutes'
      ),
      last_events AS (
        SELECT session_id, MAX(occurred_at) AS last_event
        FROM sc_tracker.events
        WHERE session_id IN (SELECT id FROM open_sessions)
        GROUP BY session_id
      )
      UPDATE sc_tracker.sessions s
      SET
        ended_at      = COALESCE(le.last_event, os.started_at),
        duration_secs = GREATEST(0, EXTRACT(EPOCH FROM (COALESCE(le.last_event, os.started_at) - os.started_at))::INTEGER)
      FROM open_sessions os
      LEFT JOIN last_events le ON le.session_id = os.id
      WHERE s.id = os.id
    `);
    if (result.rowCount && result.rowCount > 0) {
      console.log(`[seal] Sealed ${result.rowCount} orphaned session(s)`);
    }
  } catch (err) {
    console.warn('[seal] Failed to seal orphaned sessions:', err);
  }
}

async function enrichBlueprints(): Promise<void> {
  try {
    const catalog = await getBlueprintCatalog();
    if (catalog.length === 0) return;
    const rows = await pool.query<{ id: number; raw_name: string }>(
      `SELECT id, raw_name FROM sc_tracker.blueprints WHERE display_name IS NULL`
    );
    let updated = 0;
    for (const row of rows.rows) {
      const match = matchCatalog(row.raw_name, catalog);
      if (match) {
        await pool.query(
          `UPDATE sc_tracker.blueprints SET display_name=$1, category=$2, blueprint_id=$3 WHERE id=$4`,
          [match.name, match.category, match.blueprint_id, row.id]
        );
        updated++;
      }
    }
    if (updated > 0) console.log(`[blueprints] Enriched ${updated} blueprint rows from sc-craft.tools`);
  } catch (err) {
    console.warn('[blueprints] Enrichment failed:', err);
  }
}

async function main(): Promise<void> {
  await migrate();
  await seedFromNeon(pool);

  const app = express();

  // Trust Replit's TLS-terminating reverse proxy so secure cookies work in production
  app.set('trust proxy', 1);

  // Resolve views and public directories.
  // __dirname in compiled prod = dist/server/src/ → '../views' = dist/server/views/ (copied by build)
  // __dirname in dev (tsx)     = src/             → '../views' = views/  (source)
  // Fallback: process.cwd()/views if __dirname-relative path doesn't exist.
  const dirnameViews  = path.join(__dirname, '..', 'views');
  const dirnamePublic = path.join(__dirname, '..', 'public');
  const cwdViews      = path.join(process.cwd(), 'views');
  const cwdPublic     = path.join(process.cwd(), 'public');

  const viewsDir  = fs.existsSync(dirnameViews)  ? dirnameViews  : cwdViews;
  const publicDir = fs.existsSync(dirnamePublic) ? dirnamePublic : cwdPublic;

  const zipPath   = path.join(publicDir, 'downloads', 'SCTrackerAgent.zip');
  const exePath   = path.join(publicDir, 'downloads', 'SCTrackerAgent.exe');
  const zipExists = fs.existsSync(zipPath);
  const exeExists = fs.existsSync(exePath);

  console.log(`[server] __dirname=${__dirname} cwd=${process.cwd()}`);
  console.log(`[server] views=${viewsDir} public=${publicDir} zip_exists=${zipExists} exe_exists=${exeExists}`);

  app.set('view engine', 'ejs');
  app.set('views', viewsDir);

  // Primary download: ZIP (not blocked by Chrome or Discord)
  //   /downloads/agent      → SCTrackerAgent.zip
  //   /downloads/agent.zip  → same
  const serveZip = (_req: express.Request, res: express.Response) => {
    const src = zipExists ? zipPath : exePath;
    const name = zipExists ? 'SCTrackerAgent.zip' : 'SCTrackerAgent.exe';
    const mime = zipExists ? 'application/zip' : 'application/octet-stream';
    if (!zipExists && !exeExists) {
      res.status(404).send('Agent not found on server — please contact support.');
      return;
    }
    console.log('[download] Serving', name);
    res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
    res.setHeader('Content-Type', mime);
    res.setHeader('Cache-Control', 'no-cache');
    const fileStream = fs.createReadStream(src);
    fileStream.on('error', (err) => {
      console.error('[download] Read error:', err.message);
      if (!res.headersSent) res.status(500).send('Download error');
    });
    fileStream.pipe(res);
  };

  // Legacy EXE endpoint kept for backward compatibility
  const serveExe = (_req: express.Request, res: express.Response) => {
    if (!exeExists) { res.status(404).send('Not found'); return; }
    console.log('[download] Serving SCTrackerAgent.exe (legacy)');
    res.setHeader('Content-Disposition', 'attachment; filename="SCTrackerAgent.exe"');
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Cache-Control', 'no-cache');
    fs.createReadStream(exePath).pipe(res);
  };

  app.get('/downloads/agent', serveZip);
  app.get('/downloads/agent.zip', serveZip);
  app.get('/downloads/SCTrackerAgent.zip', serveZip);
  app.get('/downloads/SCTrackerAgent.exe', serveExe);

  // Static assets — same principle
  app.use(express.static(publicDir));

  // Body parsing — cap body size to defend against large-body abuse
  app.use(express.json({ limit: '128kb' }));
  app.use(express.urlencoded({ extended: false, limit: '128kb' }));

  // Session (must come before routes that use req.session)
  app.use(sessionMiddleware);

  // Redirect old replit.app domain to custom domain so OAuth callbacks always match
  const CANONICAL_HOST = 'tracker.noharmsc.org';
  app.use((req, res, next) => {
    const host = (req.headers['x-forwarded-host'] as string | undefined) ?? req.hostname;
    if (host && host !== CANONICAL_HOST && !host.startsWith('localhost') && !host.startsWith('127.')) {
      return void res.redirect(301, `https://${CANONICAL_HOST}${req.originalUrl}`);
    }
    next();
  });

  // Routes
  app.get('/', (_req, res) => res.redirect('/tracker'));
  app.get('/health', (_req, res) => res.json({ ok: true }));
  app.use('/auth', authLimiter, authRouter);
  app.use('/api/tracker', apiLimiter, trackerRouter);
  app.use('/tracker', dashboardLimiter, banCheck, dashboardRouter);

  const server = createServer(app);
  // Cap WS frame size at 64KB; handler enforces a tighter 32KB application limit.
  const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });

  const { attachWebSocket } = await import('./ws/handler');
  attachWebSocket(wss);

  // Handle WebSocket upgrades manually so we can log every attempt.
  // The path: '/ws/agent' option on WebSocketServer silently returns 400
  // for any path mismatch — this was causing spurious 400s if Replit's
  // proxy rewrites or normalises the path.  Handling it here gives us a
  // logged rejection rather than a silent one.
  server.on('upgrade', (req, socket, head) => {
    const url = req.url ?? '';
    const pathname = url.split('?')[0];
    console.log(`[ws] Upgrade request: ${pathname}`);
    if (pathname === '/ws/agent') {
      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit('connection', ws, req);
      });
    } else {
      console.log(`[ws] Rejecting upgrade for unrecognised path: ${pathname}`);
      socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
      socket.destroy();
    }
  });

  server.listen(PORT, () => {
    console.log(`[server] Listening on port ${PORT}`);
  });

  // Seal orphaned sessions (crashed agents that never sent SESSION_END)
  sealOrphanedSessions().catch(() => {});

  // Enrich any un-matched blueprints in the background after startup
  enrichBlueprints().catch(() => {});
}

main().catch((err) => {
  console.error('[server] Fatal error:', err);
  process.exit(1);
});
