import { WebSocket, WebSocketServer } from 'ws';
import { IncomingMessage } from 'http';
import { pool } from '../db/client';
import { getBlueprintCatalog, matchCatalog } from '../blueprints/catalog';
import { verifyToken } from '../auth/tokens';
import { detectHighlightsForEvent, detectHighlightsForSession, webhookDisplay } from '../highlights/detector';
import { liveBroadcaster } from '../live';
import { WsClientMessage, WsServerMessage, ParsedEvent } from '../../../shared/types';

function discordAvatarUrl(discordId: string, avatar: string | null): string {
  if (avatar) return `https://cdn.discordapp.com/avatars/${discordId}/${avatar}.png?size=64`;
  const mod = parseInt(discordId) % 5;
  return `https://cdn.discordapp.com/embed/avatars/${mod}.png`;
}

interface AuthedSocket {
  ws: WebSocket;
  userId: number;
  sessionId: number | null;
  username: string;
  discordId: string;
  avatar: string | null;
}

const connections = new Map<WebSocket, AuthedSocket>();
// Reverse index: userId -> active sockets, used to terminate sessions when
// a user's token_version is bumped or they're banned.
const userSockets = new Map<number, Set<WebSocket>>();

/**
 * Force-disconnect every active WS for a given user. Call this from places
 * that revoke authority (admin ban, /auth/rotate-token) so that an already
 * connected agent is not allowed to keep streaming with a stale token.
 */
export function revokeUserSockets(userId: number, reason: string): number {
  const set = userSockets.get(userId);
  if (!set || set.size === 0) return 0;
  let n = 0;
  for (const ws of set) {
    try {
      const msg: WsServerMessage = { type: 'auth_error', message: reason };
      if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(msg));
      ws.close(1008, reason);
    } catch {
      try { ws.terminate(); } catch { /* ignore */ }
    }
    n += 1;
  }
  return n;
}

const PING_INTERVAL_MS = 30_000;
// Replit's edge proxy can introduce 30s+ jitter on WS frame delivery, so
// we allow a generous pong window. A truly dead connection will be caught
// by either the proxy's own idle timeout or the next ping cycle anyway.
const PONG_TIMEOUT_MS = 60_000;
const MAX_MESSAGE_BYTES = 32 * 1024;
// On reconnect, the agent's flushQueue() can burst hundreds of queued events
// in a tight loop. 500/s is well above any realistic SC log emission rate
// while still cutting off a runaway client.
const MAX_MESSAGES_PER_SECOND = 500;

export function attachWebSocket(wss: WebSocketServer): void {
  wss.on('connection', (ws: WebSocket, req: IncomingMessage) => {
    const ip = req.socket.remoteAddress ?? 'unknown';
    console.log(`[ws] New connection from ${ip}`);
    let authed: AuthedSocket | null = null;
    let processing = Promise.resolve();
    let pendingPong = false;
    let pongTimer: NodeJS.Timeout | null = null;

    // Per-socket message rate limit (sliding 1s window)
    let windowStart = Date.now();
    let windowCount = 0;

    // Keep-alive: ping every 30s. If no pong arrives within 10s, terminate.
    const pingTimer = setInterval(() => {
      if (ws.readyState !== ws.OPEN) return;
      if (pendingPong) return; // already waiting
      pendingPong = true;
      ws.ping();
      pongTimer = setTimeout(() => {
        if (pendingPong && ws.readyState === ws.OPEN) {
          console.log(`[ws] No pong from ${authed?.userId ?? ip} — terminating zombie connection`);
          ws.terminate();
        }
      }, PONG_TIMEOUT_MS);
    }, PING_INTERVAL_MS);

    ws.on('pong', () => {
      pendingPong = false;
      if (pongTimer) { clearTimeout(pongTimer); pongTimer = null; }
    });

    ws.on('message', (raw, isBinary) => {
      // Reject binary frames and oversize text frames cheaply
      if (isBinary) {
        console.warn(`[ws] binary frame from ${ip} — closing`);
        ws.close(1003, 'Binary not supported');
        return;
      }
      const size = (raw as Buffer).length;
      if (size > MAX_MESSAGE_BYTES) {
        console.warn(`[ws] oversize message ${size}B from ${authed?.userId ?? ip} — closing`);
        ws.close(1009, 'Message too large');
        return;
      }

      // Per-socket rate limit
      const now = Date.now();
      if (now - windowStart >= 1000) { windowStart = now; windowCount = 0; }
      windowCount += 1;
      if (windowCount > MAX_MESSAGES_PER_SECOND) {
        console.warn(`[ws] rate limit exceeded for ${authed?.userId ?? ip} — closing`);
        ws.close(1008, 'Rate limit exceeded');
        return;
      }

      processing = processing.then(async () => {
        let msg: WsClientMessage;
        try {
          msg = JSON.parse(raw.toString()) as WsClientMessage;
        } catch {
          ws.close(1008, 'Invalid JSON');
          return;
        }

        if (msg.type === 'auth') {
          const payload = verifyToken(msg.token);
          if (!payload) {
            console.log(`[ws] Auth failed from ${ip}: invalid token`);
            const resp: WsServerMessage = { type: 'auth_error', message: 'Invalid token' };
            ws.send(JSON.stringify(resp));
            ws.close();
            return;
          }
          const result = await pool.query<{ id: number; discord_username: string; discord_id: string; discord_avatar: string | null; token_version: number; is_banned: boolean }>(
            'SELECT id, discord_username, discord_id, discord_avatar, token_version, is_banned FROM sc_tracker.users WHERE discord_id = $1',
            [payload.discordId]
          );
          if (!result.rows[0]) {
            console.log(`[ws] Auth failed from ${ip}: user not found (discord_id=${payload.discordId})`);
            const resp: WsServerMessage = { type: 'auth_error', message: 'User not found' };
            ws.send(JSON.stringify(resp));
            ws.close();
            return;
          }
          if (result.rows[0].is_banned) {
            console.log(`[ws] Banned user attempted auth: ${payload.discordId}`);
            const resp: WsServerMessage = { type: 'auth_error', message: 'Account suspended' };
            ws.send(JSON.stringify(resp));
            ws.close();
            return;
          }
          if (result.rows[0].token_version !== payload.tv) {
            console.log(`[ws] Stale token for ${payload.discordId}: agent tv=${payload.tv}, current=${result.rows[0].token_version}`);
            const resp: WsServerMessage = { type: 'auth_error', message: 'Token revoked — please re-link your agent' };
            ws.send(JSON.stringify(resp));
            ws.close();
            return;
          }
          authed = {
            ws, userId: result.rows[0].id, sessionId: null,
            username: result.rows[0].discord_username,
            discordId: result.rows[0].discord_id,
            avatar: result.rows[0].discord_avatar,
          };
          connections.set(ws, authed);
          let set = userSockets.get(authed.userId);
          if (!set) { set = new Set(); userSockets.set(authed.userId, set); }
          set.add(ws);
          console.log(`[ws] Agent authenticated: user ${result.rows[0].discord_username} (id=${authed.userId})`);
          const ok: WsServerMessage = { type: 'auth_ok', userId: authed.userId };
          ws.send(JSON.stringify(ok));
          return;
        }

        if (msg.type === 'event') {
          if (!authed) {
            ws.close(1008, 'Not authenticated');
            return;
          }
          console.log(`[ws] Event from user ${authed.userId}: ${msg.payload.type}`);
          try {
            const eventId = await storeEvent(authed, msg.payload);
            const ack: WsServerMessage = { type: 'ack', eventId };
            ws.send(JSON.stringify(ack));
          } catch (err) {
            console.error(`[ws] Failed to store ${msg.payload.type} for user ${authed.userId}:`, err);
          }
        }
      // Catch errors so one bad message never breaks the whole connection's processing chain
      }).catch((err: unknown) => {
        console.error('[ws] Unhandled message processing error:', err);
      });
    });

    ws.on('close', () => {
      clearInterval(pingTimer);
      if (pongTimer) { clearTimeout(pongTimer); pongTimer = null; }
      if (authed) {
        console.log(`[ws] Agent disconnected: user ${authed.userId}`);
        connections.delete(ws);
        const set = userSockets.get(authed.userId);
        if (set) {
          set.delete(ws);
          if (set.size === 0) userSockets.delete(authed.userId);
        }
      } else {
        console.log(`[ws] Unauthenticated connection closed from ${ip}`);
      }
    });
  });
}

async function storeEvent(conn: AuthedSocket, event: ParsedEvent): Promise<number> {
  if (event.type === 'SESSION_START') {
    const p = event.payload as { characterName: string; gameVersion: string; gameBranch: string };

    // Reconnect dedup: if there's an open session for the same user+character+version
    // started within the last 30 minutes, resume it rather than creating a duplicate.
    const existing = await pool.query<{ id: number }>(
      `SELECT id FROM sc_tracker.sessions
       WHERE user_id = $1
         AND character_name = $2
         AND game_version = $3
         AND ended_at IS NULL
         AND started_at > NOW() - INTERVAL '30 minutes'
       ORDER BY started_at DESC
       LIMIT 1`,
      [conn.userId, p.characterName, p.gameVersion]
    );

    if (existing.rows[0]) {
      conn.sessionId = existing.rows[0].id;
      console.log(`[ws] SESSION_START: resuming session ${conn.sessionId} for user ${conn.userId} (reconnect dedup)`);
    } else {
      const result = await pool.query(
        `INSERT INTO sc_tracker.sessions (user_id, character_name, game_version, game_branch, started_at)
         VALUES ($1, $2, $3, $4, $5) RETURNING id`,
        [conn.userId, p.characterName, p.gameVersion, p.gameBranch, event.occurredAt]
      );
      conn.sessionId = result.rows[0].id;
      console.log(`[ws] SESSION_START: created session ${conn.sessionId} for user ${conn.userId}`);
      // Broadcast to live community feed
      liveBroadcaster.broadcast({
        type: 'session_start',
        username: conn.username,
        discordId: conn.discordId,
        avatar: discordAvatarUrl(conn.discordId, conn.avatar),
        message: 'started a new session',
        icon: '🛸',
        ts: Date.now(),
      });
    }
  }

  if (event.type === 'SESSION_END' && conn.sessionId) {
    await pool.query(
      `UPDATE sc_tracker.sessions
       SET ended_at = $1,
           duration_secs = EXTRACT(EPOCH FROM ($1 - started_at))::INTEGER
       WHERE id = $2`,
      [event.occurredAt, conn.sessionId]
    );
  }

  const insertResult = await pool.query<{ id: number }>(
    `INSERT INTO sc_tracker.events (session_id, user_id, event_type, occurred_at, payload, parser_version)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (user_id, event_type, occurred_at) DO NOTHING
     RETURNING id`,
    [conn.sessionId, conn.userId, event.type, new Date(event.occurredAt), JSON.stringify(event.payload), parseInt(String(event.parserVersion), 10) || 1]
  );

  // If ON CONFLICT DO NOTHING fired, the event already exists — skip side-effects
  // and return the id of the pre-existing row.
  if (insertResult.rows.length === 0) {
    console.log(`[ws] Duplicate event skipped: ${event.type} at ${event.occurredAt} for user ${conn.userId}`);
    const existing = await pool.query<{ id: number }>(
      `SELECT id FROM sc_tracker.events
       WHERE user_id = $1 AND event_type = $2 AND occurred_at = $3
       LIMIT 1`,
      [conn.userId, event.type, new Date(event.occurredAt)]
    );
    return existing.rows[0].id;
  }

  const eventId = insertResult.rows[0].id;

  if (event.type === 'SHIP_CLAIM') {
    const p = event.payload as { entitlementUrn: string };
    await pool.query(
      `INSERT INTO sc_tracker.ships (user_id, entitlement_urn, claims_count, last_claimed_at)
       VALUES ($1, $2, 1, $3)
       ON CONFLICT (user_id, entitlement_urn) DO UPDATE
         SET claims_count    = sc_tracker.ships.claims_count + 1,
             last_claimed_at = EXCLUDED.last_claimed_at`,
      [conn.userId, p.entitlementUrn, event.occurredAt]
    );
  }

  if (event.type === 'BLUEPRINT_RECEIVED') {
    const p = event.payload as { blueprintName?: string };
    const rawName = p.blueprintName;
    if (rawName) {
      const catalog = await getBlueprintCatalog();
      const match = matchCatalog(rawName, catalog);
      await pool.query(
        `INSERT INTO sc_tracker.blueprints
           (user_id, raw_name, display_name, category, blueprint_id, first_received_at, times_received)
         VALUES ($1, $2, $3, $4, $5, $6, 1)
         ON CONFLICT (user_id, raw_name) DO UPDATE
           SET times_received = sc_tracker.blueprints.times_received + 1,
               display_name   = COALESCE(EXCLUDED.display_name, sc_tracker.blueprints.display_name),
               category       = COALESCE(EXCLUDED.category,     sc_tracker.blueprints.category),
               blueprint_id   = COALESCE(EXCLUDED.blueprint_id, sc_tracker.blueprints.blueprint_id)`,
        [conn.userId, rawName, match?.name ?? null, match?.category ?? null, match?.blueprint_id ?? null, event.occurredAt]
      );
    }
  }

  // Highlight detection — best-effort, never blocks the ack to the agent
  try {
    const newHighlights = await detectHighlightsForEvent(pool, conn.userId, conn.sessionId, {
      ...event,
      occurredAt: new Date(event.occurredAt),
    });
    if (event.type === 'SESSION_END' && conn.sessionId) {
      const sessionHighlights = await detectHighlightsForSession(pool, conn.userId, conn.sessionId);
      newHighlights.push(...sessionHighlights);
    }
    // Broadcast epic/major highlights to the live community feed
    for (const h of newHighlights) {
      if (h.severity === 'epic' || h.severity === 'major') {
        const { icon, title } = webhookDisplay(h.type, h.payload);
        liveBroadcaster.broadcast({
          type: 'highlight',
          username: conn.username,
          discordId: conn.discordId,
          avatar: discordAvatarUrl(conn.discordId, conn.avatar),
          message: title,
          icon,
          severity: h.severity,
          sessionId: h.sessionId ?? undefined,
          ts: Date.now(),
        });
      }
    }
  } catch (err) {
    console.error(`[highlights] detector failed for user ${conn.userId}:`, err);
  }

  return eventId;
}
