import { Request, Response, NextFunction } from 'express';
import { pool } from '../db/client';

export function adminDiscordIds(): Set<string> {
  const raw = process.env['ADMIN_DISCORD_IDS'] ?? '';
  return new Set(
    raw
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
  );
}

export function isAdmin(discordId: string | undefined): boolean {
  if (!discordId) return false;
  return adminDiscordIds().has(discordId);
}

export function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  if (!req.session.discordId || !isAdmin(req.session.discordId)) {
    res.status(403).send('Forbidden');
    return;
  }
  next();
}

/** Ban check — runs after session is loaded; logs out & 403s any banned user. */
export function banCheck(req: Request, res: Response, next: NextFunction): void {
  if (!req.session.userId) return next();
  pool
    .query<{ is_banned: boolean }>('SELECT is_banned FROM sc_tracker.users WHERE id = $1', [req.session.userId])
    .then((r) => {
      if (r.rows[0]?.is_banned) {
        req.session.destroy(() => res.status(403).send('Account suspended.'));
        return;
      }
      next();
    })
    .catch(next);
}
