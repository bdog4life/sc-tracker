import rateLimit, { ipKeyGenerator } from 'express-rate-limit';
import type { Request } from 'express';

function ipKey(req: Request): string {
  return ipKeyGenerator(req.ip ?? 'unknown');
}

export const authLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 30,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  keyGenerator: ipKey,
  message: { error: 'Too many auth requests — slow down.' },
});

export const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 120,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  keyGenerator: ipKey,
  message: { error: 'Too many API requests — slow down.' },
});

export const dashboardLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 120,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  keyGenerator: ipKey,
  // Dashboards are HTML — return a friendly page rather than JSON
  handler: (_req, res) => {
    res.status(429).send('<h1>Slow down</h1><p>Too many requests — please wait a moment and refresh.</p>');
  },
});
