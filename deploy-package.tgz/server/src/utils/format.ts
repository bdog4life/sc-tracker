export function formatGameVersion(version: string | null, branch: string | null): string {
  if (branch) {
    const m = branch.match(/(\d+\.\d+(?:\.\d+)?)$/);
    if (m) return m[1];
  }
  if (version) {
    const parts = version.split('.');
    if (parts.length >= 3) return parts.slice(0, 3).join('.');
    return version;
  }
  return '—';
}

export function formatDuration(secs: number): string {
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  if (h === 0) return `${m}m`;
  return `${h}h ${m}m`;
}

export function formatRelativeTime(date: Date): string {
  const diffMs = Date.now() - date.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  if (diffSecs < 60) return 'just now';
  const diffMins = Math.floor(diffSecs / 60);
  if (diffMins < 60) return `${diffMins}m ago`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays}d ago`;
}

export function avatarUrl(discordId: string, avatar: string | null): string {
  if (!avatar) return 'https://cdn.discordapp.com/embed/avatars/0.png';
  return `https://cdn.discordapp.com/avatars/${discordId}/${avatar}.png?size=64`;
}

type EventCategory = 'purple' | 'green' | 'amber' | 'blue';

export function eventCategory(type: string): EventCategory {
  if (type === 'SESSION_START' || type === 'SESSION_END') return 'purple';
  if (type === 'ZONE_ENTERED' || type === 'LOCATION_CHANGE') return 'green';
  if (type === 'CONTRACT_ACCEPTED' || type === 'CONTRACT_COMPLETE' || type === 'MISSION_START' || type === 'MISSION_END') return 'blue';
  if (
    type === 'SHIP_CLAIM' || type === 'SHIP_NEARBY' ||
    type === 'ATTACHMENT_RECEIVED' || type === 'ITEM_STORED'
  ) return 'amber';
  return 'blue';
}

/** Make raw SC mission module names human-readable, e.g. "LG_Bounty_PersonHunting_v2" → "Bounty: Person Hunting" */
export function formatMissionType(raw: string): string {
  if (!raw) return 'Unknown';
  let s = raw
    .replace(/^(LG|SM|GH|MG|SP|HM|PU)_/i, '')
    .replace(/^MissionGiver_/i, '')
    .replace(/_v\d+$/i, '')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/_/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return s.replace(/\b\w/g, c => c.toUpperCase()) || raw;
}

const SHIP_MFR: Record<string, string> = {
  AEGS: 'Aegis', ANVL: 'Anvil', ORIG: 'Origin', DRAK: 'Drake',
  CRUS: 'Crusader', MISC: 'MISC', RSI: 'RSI', BANU: 'Banu',
  ARGO: 'Argo', TMBL: 'Tumbril', CNOU: 'Consolidated Outland',
  GAMA: 'Gatac', KRIG: 'Kruger', MIRA: 'Mirai', ESPR: 'Esperia',
  GRIN: 'Greycat', VNCL: 'Vanduul', XIAN: "Xi'an", XNAA: "Xi'an",
  CRBC: 'Crusader', APOA: 'Aopoa', GATS: 'Gatac',
};

/** Format a raw SC ship class identifier into a readable name, e.g. "AEGS_Avenger_Stalker" → "Aegis Avenger Stalker" */
export function formatShipClass(raw: string): string {
  if (!raw) return 'Unknown Ship';
  const parts = raw.split('_');
  const mfrKey = parts[0]?.toUpperCase() ?? '';
  const mfr = SHIP_MFR[mfrKey] ?? parts[0];
  const name = parts.slice(1).join(' ');
  return name ? `${mfr} ${name}` : mfr;
}

export interface HighlightDisplay {
  icon: string;
  title: string;
  description: string;
}

export function highlightDisplay(type: string, payload: Record<string, unknown>): HighlightDisplay {
  switch (type) {
    case 'FIRST_ZONE':
      return {
        icon: '📍',
        title: 'First time visiting',
        description: String(payload['zoneName'] ?? 'a new zone'),
      };
    case 'PERSONAL_BEST_SESSION': {
      const cats = Array.isArray(payload['categories']) ? (payload['categories'] as string[]) : [];
      return {
        icon: '🏆',
        title: 'Personal best session',
        description: cats.length ? `New PB in ${cats.join(', ')}` : 'New personal record',
      };
    }
    case 'MARATHON': {
      const secs = Number(payload['durationSecs'] ?? 0);
      return {
        icon: '⏱️',
        title: 'Marathon session',
        description: `${formatDuration(secs)} of continuous play`,
      };
    }
    case 'MISSION_STREAK':
      return {
        icon: '🎯',
        title: 'Mission streak',
        description: `${payload['contracts'] ?? 0} contracts completed in one session`,
      };
    case 'BLUEPRINT_HAUL':
      return {
        icon: '📜',
        title: 'Blueprint haul',
        description: `${payload['blueprints'] ?? 0} blueprints in one session`,
      };
    case 'SHIP_LOSS_RECOVERY':
      return {
        icon: '🛠️',
        title: 'Recovered from ship loss',
        description: `Kept playing 30+ minutes after a claim`,
      };
    case 'COMEBACK':
      return {
        icon: '👋',
        title: 'Welcome back',
        description: `First session after ${payload['gapDays'] ?? '?'} days away`,
      };
    case 'BIG_DAY': {
      const secs = Number(payload['totalSecs'] ?? 0);
      return {
        icon: '🌟',
        title: 'Big day',
        description: `${formatDuration(secs)} played in 24h`,
      };
    }
    case 'RARE_SHIP':
      return {
        icon: '🛸',
        title: 'Rare ship spotted',
        description: `First sighting of ${payload['shipClass'] ?? 'an unknown ship'}`,
      };
    case 'SERVER_HOPPER':
      return {
        icon: '🔄',
        title: 'Server hopper',
        description: `Multiple session restarts in 10 minutes`,
      };
    default:
      return { icon: '✨', title: type.replace(/_/g, ' '), description: '' };
  }
}

/** Short label for the badge variant of a highlight, shown on session cards. */
export function highlightBadgeLabel(type: string): string {
  switch (type) {
    case 'PERSONAL_BEST_SESSION': return 'PB';
    case 'MARATHON': return 'Marathon';
    case 'MISSION_STREAK': return 'Streak';
    case 'BLUEPRINT_HAUL': return 'Blueprint Haul';
    case 'SHIP_LOSS_RECOVERY': return 'Recovery';
    case 'COMEBACK': return 'Comeback';
    case 'BIG_DAY': return 'Big Day';
    case 'RARE_SHIP': return 'Rare Ship';
    case 'FIRST_ZONE': return 'New Zone';
    case 'SERVER_HOPPER': return 'Hopping';
    default: return type;
  }
}

export function eventDescription(type: string, payload: Record<string, unknown>): string {
  switch (type) {
    case 'SESSION_START':      return 'Session started';
    case 'SESSION_END':        return 'Session ended';
    case 'ZONE_ENTERED':       return `${payload['notificationText'] ?? 'Zone entered'}`;
    case 'CONTRACT_ACCEPTED':  return `Contract accepted: ${payload['contractName'] ?? 'Unknown'}`;
    case 'CONTRACT_COMPLETE':  return `Contract complete: ${payload['contractName'] ?? 'Unknown'}`;
    case 'LOCATION_CHANGE':    return `Location: ${payload['fromLocationId'] ?? '?'} → ${payload['toLocationId'] ?? '?'}`;
    case 'MISSION_START':      return `Mission: ${formatMissionType(String(payload['missionType'] ?? 'Unknown'))}`;
    case 'MISSION_END':        return 'Mission ended';
    case 'SHIP_CLAIM':         return 'Insurance claim filed';
    case 'SHIP_NEARBY':        return `Ship nearby: ${formatShipClass(String(payload['shipClass'] ?? ''))}`;
    case 'ATTACHMENT_RECEIVED': return `Attachment: ${payload['attachmentName'] ?? 'unknown'}`;
    case 'ITEM_STORED':        return `Stored: ${payload['itemName'] ?? 'unknown'}`;
    case 'BLUEPRINT_RECEIVED': return `Blueprint: ${payload['blueprintName'] ?? 'unknown'}`;
    default:                   return type.replace(/_/g, ' ').toLowerCase();
  }
}

/** Build a 53-week heatmap grid from session day-aggregate rows. */
export function buildHeatmapWeeks(
  rows: Array<{ day: string; total_secs: string; session_count: string }>
): Array<Array<{ date: string; secs: number; count: number; level: number; future: boolean; label: string }>> {
  const dayMap = new Map<string, { secs: number; count: number }>();
  for (const r of rows) {
    dayMap.set(r.day, {
      secs: parseInt(r.total_secs || '0'),
      count: parseInt(r.session_count || '0'),
    });
  }

  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const startSunday = new Date(now);
  startSunday.setDate(now.getDate() - now.getDay() - 51 * 7);

  const weeks: Array<Array<{ date: string; secs: number; count: number; level: number; future: boolean; label: string }>> = [];
  const cur = new Date(startSunday);

  for (let w = 0; w < 53; w++) {
    const week = [];
    for (let d = 0; d < 7; d++) {
      const dateStr = cur.toISOString().slice(0, 10);
      const isFuture = cur > now;
      const data = dayMap.get(dateStr);
      const secs = (!isFuture && data) ? data.secs : 0;
      const count = (!isFuture && data) ? data.count : 0;
      let level = 0;
      if (secs > 0) {
        if (secs < 3600) level = 1;
        else if (secs < 7200) level = 2;
        else if (secs < 14400) level = 3;
        else level = 4;
      }
      const h = Math.floor(secs / 3600);
      const m = Math.floor((secs % 3600) / 60);
      const label = isFuture ? '' : secs === 0 ? 'No sessions' :
        `${count} session${count !== 1 ? 's' : ''} · ${h > 0 ? h + 'h ' : ''}${m}m`;
      week.push({ date: dateStr, secs, count, level, future: isFuture, label });
      cur.setDate(cur.getDate() + 1);
    }
    weeks.push(week);
  }
  return weeks;
}
