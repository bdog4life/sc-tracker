import { pool } from './client';

export async function migrate(): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    await client.query(`CREATE SCHEMA IF NOT EXISTS sc_tracker`);

    await client.query(`
      CREATE TABLE IF NOT EXISTS sc_tracker.users (
        id          SERIAL PRIMARY KEY,
        discord_id  TEXT NOT NULL UNIQUE,
        discord_username TEXT NOT NULL,
        discord_avatar   TEXT,
        token       TEXT NOT NULL UNIQUE,
        created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    // Add ban flag + token version columns (safe re-run)
    await client.query(`
      ALTER TABLE sc_tracker.users
        ADD COLUMN IF NOT EXISTS is_banned BOOLEAN NOT NULL DEFAULT FALSE
    `);
    await client.query(`
      ALTER TABLE sc_tracker.users
        ADD COLUMN IF NOT EXISTS token_version INTEGER NOT NULL DEFAULT 1
    `);
    await client.query(`
      ALTER TABLE sc_tracker.users
        ADD COLUMN IF NOT EXISTS discord_webhook_url TEXT
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS sc_tracker.sessions (
        id              SERIAL PRIMARY KEY,
        user_id         INTEGER NOT NULL REFERENCES sc_tracker.users(id),
        character_name  TEXT NOT NULL,
        game_version    TEXT,
        game_branch     TEXT,
        started_at      TIMESTAMPTZ NOT NULL,
        ended_at        TIMESTAMPTZ,
        duration_secs   INTEGER
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS sc_tracker.events (
        id             SERIAL PRIMARY KEY,
        session_id     INTEGER REFERENCES sc_tracker.sessions(id),
        user_id        INTEGER NOT NULL REFERENCES sc_tracker.users(id),
        event_type     TEXT NOT NULL,
        occurred_at    TIMESTAMPTZ NOT NULL,
        payload        JSONB NOT NULL DEFAULT '{}',
        parser_version INTEGER NOT NULL,
        created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS sc_tracker_events_user_id
        ON sc_tracker.events(user_id)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS sc_tracker_events_session_id
        ON sc_tracker.events(session_id)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS sc_tracker_events_type
        ON sc_tracker.events(event_type)
    `);

    // Create discord_notifications BEFORE the UPDATE below references it,
    // so a fresh DB doesn't fail on missing relation.
    await client.query(`
      CREATE TABLE IF NOT EXISTS sc_tracker.discord_notifications (
        id              SERIAL PRIMARY KEY,
        event_id        INTEGER REFERENCES sc_tracker.events(id),
        channel_id      TEXT NOT NULL,
        sent_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        message_preview TEXT
      )
    `);

    // Deduplicate events before adding the unique constraint.
    // Keep the row with the lowest id for each (user_id, event_type, occurred_at) group.

    // First: remap any discord_notification references that point to a duplicate
    // event row so they point to the surviving (minimum-id) row instead.
    // This prevents the subsequent DELETE from failing on the FK constraint.
    await client.query(`
      UPDATE sc_tracker.discord_notifications dn
      SET event_id = survivors.survivor_id
      FROM (
        SELECT id,
               MIN(id) OVER (PARTITION BY user_id, event_type, occurred_at) AS survivor_id
        FROM sc_tracker.events
      ) survivors
      WHERE dn.event_id = survivors.id
        AND survivors.id <> survivors.survivor_id
    `);

    // Now safe to delete the non-surviving duplicates.
    const dedupeResult = await client.query(`
      DELETE FROM sc_tracker.events
      WHERE id NOT IN (
        SELECT MIN(id)
        FROM sc_tracker.events
        GROUP BY user_id, event_type, occurred_at
      )
    `);
    if (dedupeResult.rowCount && dedupeResult.rowCount > 0) {
      console.warn(`[migrate] Removed ${dedupeResult.rowCount} duplicate event rows`);
    }

    // Add unique constraint so that replaying the log on agent restart never
    // produces duplicate rows in sc_tracker.events.
    await client.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint
          WHERE conname = 'sc_tracker_events_user_event_time_unique'
            AND conrelid = 'sc_tracker.events'::regclass
        ) THEN
          ALTER TABLE sc_tracker.events
            ADD CONSTRAINT sc_tracker_events_user_event_time_unique
            UNIQUE (user_id, event_type, occurred_at);
        END IF;
      END $$;
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS sc_tracker.ships (
        id              SERIAL PRIMARY KEY,
        user_id         INTEGER NOT NULL REFERENCES sc_tracker.users(id),
        entitlement_urn TEXT NOT NULL,
        display_name    TEXT,
        claims_count    INTEGER NOT NULL DEFAULT 0,
        last_claimed_at TIMESTAMPTZ,
        UNIQUE(user_id, entitlement_urn)
      )
    `);

    // Highlights — flagged "interesting" moments derived from events
    await client.query(`
      CREATE TABLE IF NOT EXISTS sc_tracker.highlights (
        id           SERIAL PRIMARY KEY,
        user_id      INTEGER NOT NULL REFERENCES sc_tracker.users(id),
        session_id   INTEGER REFERENCES sc_tracker.sessions(id),
        type         TEXT NOT NULL,
        severity     TEXT NOT NULL DEFAULT 'minor',
        occurred_at  TIMESTAMPTZ NOT NULL,
        payload      JSONB NOT NULL DEFAULT '{}',
        dedup_key    TEXT NOT NULL,
        created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE(user_id, type, dedup_key)
      )
    `);
    await client.query(`CREATE INDEX IF NOT EXISTS sc_tracker_highlights_user_time ON sc_tracker.highlights(user_id, occurred_at DESC)`);
    await client.query(`CREATE INDEX IF NOT EXISTS sc_tracker_highlights_session ON sc_tracker.highlights(session_id)`);
    await client.query(`CREATE INDEX IF NOT EXISTS sc_tracker_highlights_severity_time ON sc_tracker.highlights(severity, occurred_at DESC)`);

    // Temporal indexes — make recent-activity queries fast
    await client.query(`CREATE INDEX IF NOT EXISTS sc_tracker_events_user_time ON sc_tracker.events(user_id, occurred_at DESC)`);
    await client.query(`CREATE INDEX IF NOT EXISTS sc_tracker_events_time ON sc_tracker.events(occurred_at DESC)`);
    await client.query(`CREATE INDEX IF NOT EXISTS sc_tracker_sessions_user_started ON sc_tracker.sessions(user_id, started_at DESC)`);
    await client.query(`CREATE INDEX IF NOT EXISTS sc_tracker_sessions_started ON sc_tracker.sessions(started_at DESC)`);

    // Blueprints — one row per user+blueprint, enriched from sc-craft.tools
    await client.query(`
      CREATE TABLE IF NOT EXISTS sc_tracker.blueprints (
        id                SERIAL PRIMARY KEY,
        user_id           INTEGER NOT NULL REFERENCES sc_tracker.users(id),
        raw_name          TEXT NOT NULL,
        display_name      TEXT,
        category          TEXT,
        blueprint_id      TEXT,
        first_received_at TIMESTAMPTZ NOT NULL,
        times_received    INTEGER NOT NULL DEFAULT 1,
        UNIQUE(user_id, raw_name)
      )
    `);
    await client.query(`CREATE INDEX IF NOT EXISTS sc_tracker_blueprints_user ON sc_tracker.blueprints(user_id)`);
    await client.query(`CREATE INDEX IF NOT EXISTS sc_tracker_blueprints_raw ON sc_tracker.blueprints(raw_name)`);

    // Backfill blueprints from existing BLUEPRINT_RECEIVED events
    await client.query(`
      INSERT INTO sc_tracker.blueprints (user_id, raw_name, first_received_at, times_received)
      SELECT
        user_id,
        payload->>'blueprintName' AS raw_name,
        MIN(occurred_at)          AS first_received_at,
        COUNT(*)::INTEGER         AS times_received
      FROM sc_tracker.events
      WHERE event_type = 'BLUEPRINT_RECEIVED'
        AND payload->>'blueprintName' IS NOT NULL
      GROUP BY user_id, payload->>'blueprintName'
      ON CONFLICT (user_id, raw_name) DO NOTHING
    `);

    // Seasons — admin-created competitive periods
    await client.query(`
      CREATE TABLE IF NOT EXISTS sc_tracker.seasons (
        id          SERIAL PRIMARY KEY,
        name        TEXT NOT NULL,
        description TEXT,
        metric      TEXT NOT NULL,
        started_at  TIMESTAMPTZ NOT NULL,
        ended_at    TIMESTAMPTZ,
        created_by  INTEGER REFERENCES sc_tracker.users(id),
        created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    await client.query('COMMIT');
    console.log('[migrate] sc_tracker schema ready');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}
