/**
 * Seed the local (Replit) database from Neon when the target DB is empty.
 * Called automatically on server startup if NEON_DATABASE_URL is set and
 * sc_tracker.users has zero rows.
 *
 * Safe to re-run: uses TRUNCATE … RESTART IDENTITY CASCADE then bulk INSERT
 * with ON CONFLICT DO NOTHING — idempotent against the unique constraints.
 */

import { Pool, PoolClient } from 'pg';

function log(msg: string) {
  console.log(`[seed] ${msg}`);
}

async function count(client: PoolClient, schema: string, table: string): Promise<number> {
  const r = await client.query(`SELECT COUNT(*) AS n FROM ${schema}.${table}`);
  return parseInt(r.rows[0].n, 10);
}

async function copyTable(opts: {
  src: Pool;
  dst: Pool;
  schema: string;
  table: string;
  columns: string[];
  batchSize?: number;
}): Promise<number> {
  const { src, dst, schema, table, columns, batchSize = 500 } = opts;
  const q = `${schema}.${table}`;

  const srcClient = await src.connect();
  const total = await count(srcClient, schema, table);
  srcClient.release();

  if (total === 0) {
    log(`  ${q}: empty — skip`);
    return 0;
  }

  const { rows } = await src.query(
    `SELECT ${columns.join(', ')} FROM ${q} ORDER BY id`
  );

  let inserted = 0;
  for (let i = 0; i < rows.length; i += batchSize) {
    const batch = rows.slice(i, i + batchSize);
    const placeholders = batch
      .map((_, ri) =>
        '(' + columns.map((_, ci) => `$${ri * columns.length + ci + 1}`).join(', ') + ')'
      )
      .join(', ');
    const values = batch.flatMap(row => columns.map(c => row[c]));
    await dst.query(
      `INSERT INTO ${q} (${columns.join(', ')}) VALUES ${placeholders} ON CONFLICT DO NOTHING`,
      values
    );
    inserted += batch.length;
  }

  const dstClient = await dst.connect();
  const final = await count(dstClient, schema, table);
  dstClient.release();

  log(`  ${q}: ${total} from Neon → ${final} in Replit`);
  return final;
}

async function resetSeq(dst: Pool, schema: string, table: string): Promise<void> {
  await dst.query(`
    SELECT setval(
      pg_get_serial_sequence('${schema}.${table}', 'id'),
      COALESCE((SELECT MAX(id) FROM ${schema}.${table}), 0) + 1,
      false
    )
  `);
}

export async function seedFromNeon(replitPool: Pool): Promise<void> {
  const neonUrl = process.env['NEON_DATABASE_URL'];
  if (!neonUrl) {
    log('NEON_DATABASE_URL not set — skipping seed');
    return;
  }

  // Check whether the target already has data
  const check = await replitPool.query(
    `SELECT COUNT(*) AS n FROM sc_tracker.users`
  );
  if (parseInt(check.rows[0].n, 10) > 0) {
    log('Replit DB already has data — skipping seed');
    return;
  }

  log('Replit DB is empty — seeding from Neon…');

  const neon = new Pool({
    connectionString: neonUrl,
    ssl: { rejectUnauthorized: false },
    max: 5,
  });

  try {
    // Truncate in reverse FK order then copy in FK-safe order
    await replitPool.query(`
      TRUNCATE
        sc_tracker.discord_notifications,
        sc_tracker.highlights,
        sc_tracker.blueprints,
        sc_tracker.ships,
        sc_tracker.events,
        sc_tracker.sessions,
        sc_tracker.seasons,
        sc_tracker.users
      RESTART IDENTITY CASCADE
    `);

    await copyTable({ src: neon, dst: replitPool, schema: 'sc_tracker', table: 'users',
      columns: ['id','discord_id','discord_username','discord_avatar','token',
                'created_at','updated_at','is_banned','token_version','discord_webhook_url'] });

    await copyTable({ src: neon, dst: replitPool, schema: 'sc_tracker', table: 'sessions',
      columns: ['id','user_id','character_name','game_version','game_branch',
                'started_at','ended_at','duration_secs'] });

    await copyTable({ src: neon, dst: replitPool, schema: 'sc_tracker', table: 'events',
      columns: ['id','session_id','user_id','event_type','occurred_at',
                'payload','parser_version','created_at'],
      batchSize: 200 });

    await copyTable({ src: neon, dst: replitPool, schema: 'sc_tracker', table: 'ships',
      columns: ['id','user_id','entitlement_urn','display_name','claims_count','last_claimed_at'] });

    await copyTable({ src: neon, dst: replitPool, schema: 'sc_tracker', table: 'highlights',
      columns: ['id','user_id','session_id','type','severity',
                'occurred_at','payload','dedup_key','created_at'] });

    await copyTable({ src: neon, dst: replitPool, schema: 'sc_tracker', table: 'blueprints',
      columns: ['id','user_id','raw_name','display_name','category',
                'blueprint_id','first_received_at','times_received'] });

    await copyTable({ src: neon, dst: replitPool, schema: 'sc_tracker', table: 'seasons',
      columns: ['id','name','description','metric','started_at','ended_at','created_by','created_at'] });

    await copyTable({ src: neon, dst: replitPool, schema: 'sc_tracker', table: 'discord_notifications',
      columns: ['id','event_id','channel_id','sent_at','message_preview'] });

    // Copy active browser sessions
    try {
      const { rows: sess } = await neon.query(
        `SELECT sid, sess, expire FROM public.session WHERE expire > NOW()`
      );
      for (const s of sess) {
        await replitPool.query(
          `INSERT INTO public.session (sid, sess, expire) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`,
          [s.sid, s.sess, s.expire]
        );
      }
      log(`  public.session: copied ${sess.length} active session(s)`);
    } catch {
      log('  public.session: not found in Neon — skipping');
    }

    // Reset sequences
    for (const t of ['users','sessions','events','ships','highlights','blueprints','seasons','discord_notifications']) {
      await resetSeq(replitPool, 'sc_tracker', t);
    }

    log('Seed complete.');
  } finally {
    await neon.end();
  }
}
