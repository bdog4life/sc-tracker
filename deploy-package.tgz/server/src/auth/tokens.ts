import jwt from 'jsonwebtoken';

const secret = process.env['JWT_SECRET'];
if (!secret) throw new Error('JWT_SECRET environment variable is required');

export interface TokenPayload {
  discordId: string;
  tv: number;
}

export function generateToken(discordId: string, tokenVersion: number): string {
  return jwt.sign({ discordId, tv: tokenVersion }, secret!, { expiresIn: '1y' });
}

export function verifyToken(token: string): TokenPayload | null {
  try {
    const decoded = jwt.verify(token, secret!) as Partial<TokenPayload>;
    if (typeof decoded.discordId !== 'string') return null;
    return {
      discordId: decoded.discordId,
      tv: typeof decoded.tv === 'number' ? decoded.tv : 1,
    };
  } catch {
    return null;
  }
}
