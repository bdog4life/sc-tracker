// server/src/routes/dashboard.ts
import { Router, Request, Response, NextFunction } from 'express';
import { pool } from '../db/client';
import { requireAuth } from '../middleware/session';
import { requireAdmin, isAdmin } from '../middleware/security';
import { revokeUserSockets } from '../ws/handler';
import { liveBroadcaster } from '../live';
import {
  formatDuration, formatRelativeTime, avatarUrl,
  eventDescription, eventCategory, formatGameVersion,
  highlightDisplay, highlightBadgeLabel,
  formatMissionType, formatShipClass, buildHeatmapWeeks,
} from '../utils/format';

export const dashboardRouter = Router();

function theme(req: Request): 'dark-purple' | 'dark-amber' {
  return req.session.theme ?? 'dark-purple';
}

// Fix 2: asyncRoute wrapper for unhandled async errors in Express 4
function asyncRoute(fn: (req: Request, res: Response, next: NextFunction) => Promise<void>) {
  return (req: Request, res: Response, next: NextFunction) =>
    fn(req, res, next).catch(next);
}

// Common locals: nav badges that depend on the logged-in user
function navLocals(req: Request) {
  return {
    currentPath: req.path,
    isAdmin: isAdmin(req.session.discordId),
  };
}

function formatBranch(branch: string): string {
  return branch.replace(/^sc-alpha-/, '');
}

async function getAvailableBranches(): Promise<Array<{ value: string; label: string }>> {
  const r = await pool.query<{ game_branch: string }>(
    `SELECT DISTINCT game_branch FROM sc_tracker.sessions
     WHERE game_branch IS NOT NULL ORDER BY game_branch`
  );
  return r.rows.map(row => ({ value: row.game_branch, label: formatBranch(row.game_branch) }));
}

function branchOf(req: Request): string {
  return (req.query['branch'] as string) || '';
}

/** Fetch session-level highlight badges for a list of session ids. */
async function fetchSessionBadges(sessionIds: number[]): Promise<Map<number, Array<{type: string; severity: string; label: string}>>> {
  const m = new Map<number, Array<{type: string; severity: string; label: string}>>();
  if (sessionIds.length === 0) return m;
  const rows = await pool.query<{ session_id: number; type: string; severity: string }>(
    `SELECT session_id, type, severity
     FROM sc_tracker.highlights
     WHERE session_id = ANY($1::int[])
       AND type <> 'SERVER_HOPPER'
     ORDER BY occurred_at DESC`,
    [sessionIds]
  );
  for (const r of rows.rows) {
    const list = m.get(r.session_id) ?? [];
    list.push({ type: r.type, severity: r.severity, label: highlightBadgeLabel(r.type) });
    m.set(r.session_id, list);
  }
  return m;
}

// ── GET /tracker ─────────────────────────────────────────────────────────────

dashboardRouter.get('/', requireAuth, asyncRoute(async (req, res) => {
  const userId = req.session.userId!;
  const branch = branchOf(req);
  const branchParam = branch || null;

  const [aggRow, lastSession, recentEvents, rankRow, recentHighlights, onlineRow, branches] = await Promise.all([
    // Aggregate stats — all scoped to branch if provided
    pool.query<{
      total_playtime_secs: string;
      session_count: string;
      mission_count: string;
      ships_lost: string;
      zones_visited: string;
      contracts_completed: string;
    }>(`
      SELECT
        (SELECT COALESCE(SUM(duration_secs), 0) FROM sc_tracker.sessions
         WHERE user_id = $1 AND ($2::text IS NULL OR game_branch = $2)) AS total_playtime_secs,
        (SELECT COUNT(*) FROM sc_tracker.sessions
         WHERE user_id = $1 AND ($2::text IS NULL OR game_branch = $2)) AS session_count,
        (SELECT COUNT(*) FROM sc_tracker.events e WHERE user_id = $1 AND event_type = 'MISSION_START'
         AND ($2::text IS NULL OR EXISTS(SELECT 1 FROM sc_tracker.sessions s WHERE s.id=e.session_id AND s.game_branch=$2))) AS mission_count,
        (SELECT COUNT(*) FROM sc_tracker.events e WHERE user_id = $1 AND event_type = 'SHIP_CLAIM'
         AND ($2::text IS NULL OR EXISTS(SELECT 1 FROM sc_tracker.sessions s WHERE s.id=e.session_id AND s.game_branch=$2))) AS ships_lost,
        (SELECT COUNT(*) FROM sc_tracker.events e WHERE user_id = $1 AND event_type = 'ZONE_ENTERED'
         AND ($2::text IS NULL OR EXISTS(SELECT 1 FROM sc_tracker.sessions s WHERE s.id=e.session_id AND s.game_branch=$2))) AS zones_visited,
        (SELECT COUNT(*) FROM sc_tracker.events e WHERE user_id = $1 AND event_type = 'CONTRACT_COMPLETE'
         AND ($2::text IS NULL OR EXISTS(SELECT 1 FROM sc_tracker.sessions s WHERE s.id=e.session_id AND s.game_branch=$2))) AS contracts_completed
    `, [userId, branchParam]),

    pool.query<{
      id: number; character_name: string; game_version: string | null;
      game_branch: string | null; started_at: Date; effective_duration: number;
      zone_count: string; mission_count: string; ships_lost: string; blueprint_count: string;
      contract_count: string;
    }>(`
      SELECT
        s.id, s.character_name, s.game_version, s.game_branch, s.started_at,
        COALESCE(
          s.duration_secs,
          EXTRACT(EPOCH FROM (MAX(e.occurred_at) - s.started_at))::INTEGER,
          0
        ) AS effective_duration,
        COUNT(e.id) FILTER (WHERE e.event_type = 'ZONE_ENTERED') AS zone_count,
        COUNT(e.id) FILTER (WHERE e.event_type = 'MISSION_START') AS mission_count,
        COUNT(e.id) FILTER (WHERE e.event_type = 'SHIP_CLAIM') AS ships_lost,
        COUNT(e.id) FILTER (WHERE e.event_type = 'BLUEPRINT_RECEIVED') AS blueprint_count,
        COUNT(e.id) FILTER (WHERE e.event_type = 'CONTRACT_COMPLETE') AS contract_count
      FROM sc_tracker.sessions s
      LEFT JOIN sc_tracker.events e ON e.session_id = s.id
      WHERE s.user_id = $1 AND ($2::text IS NULL OR s.game_branch = $2)
      GROUP BY s.id
      ORDER BY s.started_at DESC
      LIMIT 6
    `, [userId, branchParam]),

    pool.query<{ event_type: string; payload: Record<string, unknown>; occurred_at: Date }>(`
      SELECT e.event_type, e.payload, e.occurred_at
      FROM sc_tracker.events e
      LEFT JOIN sc_tracker.sessions ses ON ses.id = e.session_id
      WHERE e.user_id = $1
        AND ($2::text IS NULL OR ses.game_branch = $2)
        AND e.event_type NOT IN ('ATTACHMENT_RECEIVED', 'MISSION_CONTRACT')
        AND NOT (
          e.event_type = 'MISSION_START' AND (
            e.payload->>'missionType' LIKE '%FrontendHangar%' OR
            e.payload->>'missionType' LIKE '%/EA/%'
          )
        )
        AND NOT (
          e.event_type = 'MISSION_END' AND e.payload->>'entityId' IN (
            SELECT payload->>'entityId'
            FROM sc_tracker.events
            WHERE user_id = $1
              AND event_type = 'MISSION_START'
              AND (
                payload->>'missionType' LIKE '%FrontendHangar%' OR
                payload->>'missionType' LIKE '%/EA/%'
              )
          )
        )
      ORDER BY e.occurred_at DESC
      LIMIT 10
    `, [userId, branchParam]),

    pool.query<{ rank: string }>(`
      WITH ranks AS (
        SELECT user_id, RANK() OVER (ORDER BY COUNT(*) DESC) AS rank
        FROM sc_tracker.events
        WHERE event_type = 'MISSION_START'
        GROUP BY user_id
      )
      SELECT rank FROM ranks WHERE user_id = $1
    `, [userId]),

    pool.query<{
      id: number; session_id: number | null; type: string; severity: string;
      occurred_at: Date; payload: Record<string, unknown>;
    }>(`
      SELECT h.id, h.session_id, h.type, h.severity, h.occurred_at, h.payload
      FROM sc_tracker.highlights h
      LEFT JOIN sc_tracker.sessions ses ON ses.id = h.session_id
      WHERE h.user_id = $1 AND h.type <> 'SERVER_HOPPER'
        AND ($2::text IS NULL OR ses.game_branch = $2)
      ORDER BY h.occurred_at DESC
      LIMIT 5
    `, [userId, branchParam]),

    pool.query<{ discord_id: string; discord_username: string; discord_avatar: string | null }>(`
      SELECT DISTINCT u.discord_id, u.discord_username, u.discord_avatar
      FROM sc_tracker.users u
      WHERE EXISTS (
        SELECT 1 FROM sc_tracker.events e
        WHERE e.user_id = u.id AND e.occurred_at > NOW() - INTERVAL '5 minutes'
      )
      ORDER BY u.discord_username
    `),

    getAvailableBranches(),
  ]);

  const stats = aggRow.rows[0];
  const sessions = lastSession.rows;
  const heroSession = sessions[0] ?? null;
  const recentSessions = sessions.slice(1);

  const sessionIds = sessions.map(s => s.id);
  const badges = await fetchSessionBadges(sessionIds);

  res.render('overview', {
    title: 'Overview',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    branches,
    currentBranch: branch,
    stats: {
      totalPlaytime: formatDuration(parseInt(stats?.total_playtime_secs ?? '0')),
      sessionCount: parseInt(stats?.session_count ?? '0'),
      missionCount: parseInt(stats?.mission_count ?? '0'),
      shipsLost: parseInt(stats?.ships_lost ?? '0'),
      zonesVisited: parseInt(stats?.zones_visited ?? '0'),
      contractsCompleted: parseInt(stats?.contracts_completed ?? '0'),
      rank: rankRow.rows[0] ? parseInt(rankRow.rows[0].rank) : null,
    },
    heroSession: heroSession ? {
      ...heroSession,
      durationFormatted: formatDuration(heroSession.effective_duration ?? 0),
      startedAtFormatted: new Date(heroSession.started_at).toLocaleString(),
      gameVersionFormatted: formatGameVersion(heroSession.game_version, heroSession.game_branch),
      badges: badges.get(heroSession.id) ?? [],
      contract_count: heroSession.contract_count,
    } : null,
    recentSessions: recentSessions.map(s => ({
      ...s,
      durationFormatted: formatDuration(s.effective_duration ?? 0),
      startedAtFormatted: new Date(s.started_at).toLocaleDateString(),
      gameVersionFormatted: formatGameVersion(s.game_version, s.game_branch),
      badges: badges.get(s.id) ?? [],
    })),
    recentEvents: recentEvents.rows.map(e => ({
      ...e,
      description: eventDescription(e.event_type, e.payload),
      relativeTime: formatRelativeTime(new Date(e.occurred_at)),
    })),
    recentHighlights: recentHighlights.rows.map(h => {
      const d = highlightDisplay(h.type, h.payload);
      return {
        ...h,
        icon: d.icon,
        title: d.title,
        description: d.description,
        relativeTime: formatRelativeTime(new Date(h.occurred_at)),
      };
    }),
    onlineUsers: onlineRow.rows.map(u => ({
      discordId: u.discord_id,
      username: u.discord_username,
      avatar: avatarUrl(u.discord_id, u.discord_avatar),
      isMe: u.discord_id === req.session.discordId,
    })),
  });
}));

// ── GET /tracker/sessions ─────────────────────────────────────────────────────

dashboardRouter.get('/sessions', requireAuth, asyncRoute(async (req, res) => {
  const userId = req.session.userId!;
  const page = Math.max(1, parseInt(req.query['page'] as string || '1', 10));
  const perPage = 25;
  const offset = (page - 1) * perPage;
  const branch = branchOf(req);
  const branchParam = branch || null;

  // Date range filter
  const validRanges = ['today', '7d', '30d', 'all'] as const;
  type DateRange = typeof validRanges[number];
  const dateRange: DateRange = validRanges.includes(req.query['range'] as DateRange)
    ? (req.query['range'] as DateRange) : 'all';
  const rangeClause = dateRange === 'today' ? `AND s.started_at >= NOW() - INTERVAL '1 day'`
    : dateRange === '7d'  ? `AND s.started_at >= NOW() - INTERVAL '7 days'`
    : dateRange === '30d' ? `AND s.started_at >= NOW() - INTERVAL '30 days'`
    : '';

  const [totalRow, rows, branches] = await Promise.all([
    pool.query<{ total: string }>(
      `SELECT COUNT(*) AS total FROM sc_tracker.sessions s
       WHERE s.user_id = $1 AND ($2::text IS NULL OR s.game_branch = $2) ${rangeClause}`,
      [userId, branchParam]
    ),
    pool.query<{
      id: number; started_at: Date; effective_duration: number;
      game_version: string | null; game_branch: string | null;
      zone_count: string; mission_count: string; ships_lost: string; contracts: string;
    }>(`
      SELECT
        s.id, s.started_at, s.game_version, s.game_branch,
        COALESCE(
          s.duration_secs,
          EXTRACT(EPOCH FROM (MAX(e.occurred_at) - s.started_at))::INTEGER,
          0
        ) AS effective_duration,
        COUNT(e.id) FILTER (WHERE e.event_type = 'ZONE_ENTERED') AS zone_count,
        COUNT(e.id) FILTER (WHERE e.event_type = 'MISSION_START') AS mission_count,
        COUNT(e.id) FILTER (WHERE e.event_type = 'SHIP_CLAIM') AS ships_lost,
        COUNT(e.id) FILTER (WHERE e.event_type = 'CONTRACT_COMPLETE') AS contracts
      FROM sc_tracker.sessions s
      LEFT JOIN sc_tracker.events e ON e.session_id = s.id
      WHERE s.user_id = $1 AND ($4::text IS NULL OR s.game_branch = $4) ${rangeClause}
      GROUP BY s.id
      ORDER BY s.started_at DESC
      LIMIT $2 OFFSET $3
    `, [userId, perPage, offset, branchParam]),
    getAvailableBranches(),
  ]);

  const total = parseInt(totalRow.rows[0]?.total ?? '0');
  const totalPages = Math.ceil(total / perPage);
  const badges = await fetchSessionBadges(rows.rows.map(s => s.id));

  res.render('sessions', {
    title: 'Sessions',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    branches,
    currentBranch: branch,
    dateRange,
    sessions: rows.rows.map(s => ({
      ...s,
      durationFormatted: formatDuration(s.effective_duration ?? 0),
      startedAtFormatted: new Date(s.started_at).toLocaleString(),
      gameVersionFormatted: formatGameVersion(s.game_version, s.game_branch),
      badges: badges.get(s.id) ?? [],
    })),
    page,
    totalPages,
    total,
  });
}));

// ── GET /tracker/sessions/:id/share (public) ──────────────────────────────────

dashboardRouter.get('/sessions/:id/share', asyncRoute(async (req, res) => {
  const sessionId = parseInt(req.params['id'], 10);
  if (isNaN(sessionId)) { res.status(404).send('Not found'); return; }

  const [sessionRow, eventsRow, highlightsRow] = await Promise.all([
    pool.query<{
      id: number; character_name: string; game_version: string | null; game_branch: string | null;
      started_at: Date; effective_duration: number;
      discord_username: string; discord_avatar: string | null; discord_id: string;
    }>(`
      SELECT
        s.id, s.character_name, s.game_version, s.game_branch, s.started_at,
        COALESCE(s.duration_secs,
          (SELECT EXTRACT(EPOCH FROM (MAX(e.occurred_at) - s.started_at))::INTEGER
           FROM sc_tracker.events e WHERE e.session_id = s.id), 0
        ) AS effective_duration,
        u.discord_username, u.discord_avatar, u.discord_id
      FROM sc_tracker.sessions s
      JOIN sc_tracker.users u ON u.id = s.user_id
      WHERE s.id = $1 AND u.is_banned = FALSE
    `, [sessionId]),

    pool.query<{ event_type: string }>(`
      SELECT event_type FROM sc_tracker.events WHERE session_id = $1
    `, [sessionId]),

    pool.query<{ type: string; severity: string; payload: Record<string, unknown> }>(`
      SELECT type, severity, payload FROM sc_tracker.highlights
      WHERE session_id = $1 ORDER BY occurred_at ASC
    `, [sessionId]),
  ]);

  if (!sessionRow.rows[0]) { res.status(404).send('Session not found'); return; }
  const s = sessionRow.rows[0];
  const evts = eventsRow.rows;

  res.render('session-share', {
    session: {
      id: s.id,
      characterName: s.character_name,
      username: s.discord_username,
      avatar: avatarUrl(s.discord_id, s.discord_avatar),
      gameVersionFormatted: formatGameVersion(s.game_version, s.game_branch),
      startedAt: new Date(s.started_at).toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' }),
      durationFormatted: formatDuration(Number(s.effective_duration) || 0),
      zoneCount: evts.filter(e => e.event_type === 'ZONE_ENTERED').length,
      missionCount: evts.filter(e => e.event_type === 'MISSION_START').length,
      contractCount: evts.filter(e => e.event_type === 'CONTRACT_COMPLETE').length,
      shipsLost: evts.filter(e => e.event_type === 'SHIP_CLAIM').length,
    },
    highlights: highlightsRow.rows
      .filter(h => h.severity !== 'info')
      .map(h => {
        const d = highlightDisplay(h.type, h.payload);
        return { ...h, icon: d.icon, title: d.title, description: d.description };
      }),
  });
}));

// ── GET /tracker/sessions/:id ─────────────────────────────────────────────────

dashboardRouter.get('/sessions/:id', requireAuth, asyncRoute(async (req, res) => {
  const userId = req.session.userId!;
  const sessionId = parseInt(req.params['id'], 10);
  if (isNaN(sessionId)) { res.status(404).send('Not found'); return; }

  // Fix 1: sequential queries — check ownership before fetching events (IDOR prevention)
  const sessionRow = await pool.query<{
    id: number; character_name: string; game_version: string | null;
    game_branch: string | null; started_at: Date; effective_duration: number;
  }>(`
    SELECT
      s.id, s.character_name, s.game_version, s.game_branch, s.started_at,
      COALESCE(
        s.duration_secs,
        (SELECT EXTRACT(EPOCH FROM (MAX(e.occurred_at) - s.started_at))::INTEGER
         FROM sc_tracker.events e WHERE e.session_id = s.id),
        0
      ) AS effective_duration
    FROM sc_tracker.sessions s
    WHERE s.id = $1 AND s.user_id = $2
  `, [sessionId, userId]);

  if (!sessionRow.rows[0]) { res.status(404).send('Session not found'); return; }
  const s = sessionRow.rows[0];

  const [eventsRow, highlightsRow] = await Promise.all([
    pool.query<{ event_type: string; payload: Record<string, unknown>; occurred_at: Date }>(`
      SELECT event_type, payload, occurred_at
      FROM sc_tracker.events
      WHERE session_id = $1
      ORDER BY occurred_at ASC
    `, [sessionId]),
    pool.query<{ id: number; type: string; severity: string; payload: Record<string, unknown>; occurred_at: Date }>(`
      SELECT id, type, severity, payload, occurred_at
      FROM sc_tracker.highlights
      WHERE session_id = $1
      ORDER BY occurred_at ASC
    `, [sessionId]),
  ]);

  const contractsCount = eventsRow.rows.filter(e => e.event_type === 'CONTRACT_COMPLETE').length;

  res.render('session-detail', {
    title: 'Session Detail',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    session: {
      ...s,
      durationFormatted: formatDuration(s.effective_duration ?? 0),
      startedAtFormatted: new Date(s.started_at).toLocaleString(),
      gameVersionFormatted: formatGameVersion(s.game_version, s.game_branch),
    },
    contractsCount,
    highlights: highlightsRow.rows.map(h => {
      const d = highlightDisplay(h.type, h.payload);
      return { ...h, icon: d.icon, title: d.title, description: d.description };
    }),
    events: eventsRow.rows.map(e => ({
      ...e,
      description: eventDescription(e.event_type, e.payload),
      category: eventCategory(e.event_type),
      timeFormatted: new Date(e.occurred_at).toLocaleTimeString(),
      relativeTime: formatRelativeTime(new Date(e.occurred_at)),
    })),
  });
}));

// ── GET /tracker/leaderboard ──────────────────────────────────────────────────

type LeaderboardBy = 'missions' | 'playtime' | 'sessions' | 'ships' | 'zones' | 'contracts';

async function leaderboardQuery(by: LeaderboardBy, branch: string | null, since: string | null): Promise<Array<{
  discord_id: string; discord_username: string; discord_avatar: string | null; metric: number;
}>> {
  let sql: string;
  const params: (string | null)[] = [branch, since];
  // $1 = branch filter, $2 = since timestamp (ISO string or null for all-time)
  switch (by) {
    case 'missions':
      sql = `
        SELECT u.discord_id, u.discord_username, u.discord_avatar,
               COUNT(e.id) AS metric
        FROM sc_tracker.users u
        LEFT JOIN sc_tracker.events e ON e.user_id = u.id AND e.event_type = 'MISSION_START'
        LEFT JOIN sc_tracker.sessions s ON s.id = e.session_id
        WHERE ($1::text IS NULL OR s.game_branch = $1)
          AND ($2::timestamptz IS NULL OR e.occurred_at >= $2::timestamptz)
        GROUP BY u.id ORDER BY metric DESC LIMIT 100`;
      break;
    case 'playtime':
      sql = `
        SELECT u.discord_id, u.discord_username, u.discord_avatar,
               COALESCE(SUM(COALESCE(s.duration_secs,0)), 0) AS metric
        FROM sc_tracker.users u
        LEFT JOIN sc_tracker.sessions s ON s.user_id = u.id
          AND ($1::text IS NULL OR s.game_branch = $1)
          AND ($2::timestamptz IS NULL OR s.started_at >= $2::timestamptz)
        GROUP BY u.id ORDER BY metric DESC LIMIT 100`;
      break;
    case 'sessions':
      sql = `
        SELECT u.discord_id, u.discord_username, u.discord_avatar,
               COUNT(s.id) AS metric
        FROM sc_tracker.users u
        LEFT JOIN sc_tracker.sessions s ON s.user_id = u.id
          AND ($1::text IS NULL OR s.game_branch = $1)
          AND ($2::timestamptz IS NULL OR s.started_at >= $2::timestamptz)
        GROUP BY u.id ORDER BY metric DESC LIMIT 100`;
      break;
    case 'ships':
      sql = `
        SELECT u.discord_id, u.discord_username, u.discord_avatar,
               COUNT(e.id) AS metric
        FROM sc_tracker.users u
        LEFT JOIN sc_tracker.events e ON e.user_id = u.id AND e.event_type = 'SHIP_CLAIM'
        LEFT JOIN sc_tracker.sessions s ON s.id = e.session_id
        WHERE ($1::text IS NULL OR s.game_branch = $1)
          AND ($2::timestamptz IS NULL OR e.occurred_at >= $2::timestamptz)
        GROUP BY u.id ORDER BY metric DESC LIMIT 100`;
      break;
    case 'zones':
      sql = `
        SELECT u.discord_id, u.discord_username, u.discord_avatar,
               COUNT(e.id) AS metric
        FROM sc_tracker.users u
        LEFT JOIN sc_tracker.events e ON e.user_id = u.id AND e.event_type = 'ZONE_ENTERED'
        LEFT JOIN sc_tracker.sessions s ON s.id = e.session_id
        WHERE ($1::text IS NULL OR s.game_branch = $1)
          AND ($2::timestamptz IS NULL OR e.occurred_at >= $2::timestamptz)
        GROUP BY u.id ORDER BY metric DESC LIMIT 100`;
      break;
    case 'contracts':
      sql = `
        SELECT u.discord_id, u.discord_username, u.discord_avatar,
               COUNT(e.id) AS metric
        FROM sc_tracker.users u
        LEFT JOIN sc_tracker.events e ON e.user_id = u.id AND e.event_type = 'CONTRACT_COMPLETE'
        LEFT JOIN sc_tracker.sessions s ON s.id = e.session_id
        WHERE ($1::text IS NULL OR s.game_branch = $1)
          AND ($2::timestamptz IS NULL OR e.occurred_at >= $2::timestamptz)
        GROUP BY u.id ORDER BY metric DESC LIMIT 100`;
      break;
  }
  const result = await pool.query<{
    discord_id: string; discord_username: string; discord_avatar: string | null; metric: number;
  }>(sql, params);
  return result.rows;
}

dashboardRouter.get('/leaderboard', requireAuth, asyncRoute(async (req, res) => {
  const validBy: LeaderboardBy[] = ['missions', 'playtime', 'sessions', 'ships', 'zones', 'contracts'];
  const by: LeaderboardBy = validBy.includes(req.query['by'] as LeaderboardBy)
    ? (req.query['by'] as LeaderboardBy)
    : 'missions';

  const myDiscordId = req.session.discordId!;
  const branch = branchOf(req);
  const branchParam = branch || null;

  const validLbRanges = ['7d', '30d', 'all'] as const;
  type LbRange = typeof validLbRanges[number];
  const lbRange: LbRange = validLbRanges.includes(req.query['range'] as LbRange)
    ? (req.query['range'] as LbRange) : 'all';
  const sinceLb: string | null = lbRange === '7d'
    ? new Date(Date.now() - 7 * 86400_000).toISOString()
    : lbRange === '30d'
    ? new Date(Date.now() - 30 * 86400_000).toISOString()
    : null;

  const [rows, onlineRow, branches] = await Promise.all([
    leaderboardQuery(by, branchParam, sinceLb),
    pool.query<{ discord_id: string }>(`
      SELECT DISTINCT u.discord_id
      FROM sc_tracker.users u
      WHERE EXISTS (
        SELECT 1 FROM sc_tracker.events e
        WHERE e.user_id = u.id
          AND e.occurred_at > NOW() - INTERVAL '5 minutes'
      )
    `),
    getAvailableBranches(),
  ]);

  const onlineIds = new Set(onlineRow.rows.map(r => r.discord_id));

  res.render('leaderboard', {
    title: 'Leaderboard',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(myDiscordId, req.session.avatar ?? null) },
    ...navLocals(req),
    branches,
    currentBranch: branch,
    by,
    lbRange,
    rows: rows.map((r, i) => ({
      rank: i + 1,
      discordId: r.discord_id,
      username: r.discord_username,
      avatar: avatarUrl(r.discord_id, r.discord_avatar),
      metric: by === 'playtime' ? formatDuration(r.metric) : r.metric.toString(),
      isMe: r.discord_id === myDiscordId,
      isOnline: onlineIds.has(r.discord_id),
    })),
  });
}));

// ── GET /tracker/blueprints ───────────────────────────────────────────────────

dashboardRouter.get('/blueprints', requireAuth, asyncRoute(async (req, res) => {
  const myDiscordId = req.session.discordId!;
  const myUserId    = req.session.userId!;

  const playerFilter   = (req.query['player']   as string | undefined) || '';
  const categoryFilter = (req.query['category'] as string | undefined) || '';
  const bpBranch       = (req.query['branch']   as string | undefined) || '';
  const mineOnly       = req.query['mine'] === '1';

  // Resolve player filter to a user_id (empty = all)
  let filterUserId: number | null = null;
  if (playerFilter === 'me') {
    filterUserId = myUserId;
  } else if (playerFilter) {
    const r = await pool.query<{ id: number }>(
      `SELECT id FROM sc_tracker.users WHERE discord_id = $1`, [playerFilter]
    );
    filterUserId = r.rows[0]?.id ?? null;
  }

  // All users who have at least one blueprint (for the player dropdown)
  const playersRow = await pool.query<{
    discord_id: string; discord_username: string; discord_avatar: string | null;
  }>(`
    SELECT DISTINCT u.discord_id, u.discord_username, u.discord_avatar
    FROM sc_tracker.blueprints b
    JOIN sc_tracker.users u ON u.id = b.user_id
    ORDER BY u.discord_username
  `);

  // All distinct categories (for the category dropdown)
  const categoriesRow = await pool.query<{ category: string }>(`
    SELECT DISTINCT category FROM sc_tracker.blueprints
    WHERE category IS NOT NULL ORDER BY category
  `);

  // Resolve "mine only" toggle — overrides player filter
  const effectiveUserId: number | null = mineOnly ? myUserId : filterUserId;

  // Main blueprint query — one row per (raw_name, user), aggregated in JS for group view
  // Branch filter: blueprints table has no branch column, so we join to the first
  // BLUEPRINT_RECEIVED event for that user+raw_name and filter via its session's branch.
  const bpRows = await pool.query<{
    raw_name: string;
    display_name: string | null;
    category: string | null;
    blueprint_id: string | null;
    first_received_at: Date;
    times_received: number;
    discord_id: string;
    discord_username: string;
    discord_avatar: string | null;
  }>(`
    SELECT
      b.raw_name, b.display_name, b.category, b.blueprint_id,
      b.first_received_at, b.times_received,
      u.discord_id, u.discord_username, u.discord_avatar
    FROM sc_tracker.blueprints b
    JOIN sc_tracker.users u ON u.id = b.user_id
    WHERE ($1::int IS NULL OR b.user_id = $1)
      AND ($2::text IS NULL OR $2 = '' OR b.category = $2)
      AND ($3::text IS NULL OR $3 = '' OR EXISTS (
        SELECT 1 FROM sc_tracker.events e
        JOIN sc_tracker.sessions s ON s.id = e.session_id
        WHERE e.user_id = b.user_id
          AND e.event_type = 'BLUEPRINT_RECEIVED'
          AND e.payload->>'name' = b.raw_name
          AND s.game_branch = $3
      ))
    ORDER BY b.category NULLS LAST, COALESCE(b.display_name, b.raw_name), b.first_received_at
  `, [effectiveUserId, categoryFilter || null, bpBranch || null]);

  // Group by blueprint raw_name
  const blueprintMap = new Map<string, {
    rawName: string;
    displayName: string;
    category: string;
    blueprintId: string | null;
    firstReceived: Date;
    owners: Array<{ discordId: string; username: string; avatar: string; isMe: boolean; firstReceivedAt: Date; times: number }>;
  }>();

  for (const r of bpRows.rows) {
    if (!blueprintMap.has(r.raw_name)) {
      blueprintMap.set(r.raw_name, {
        rawName: r.raw_name,
        displayName: r.display_name ?? r.raw_name.replace(/^@item_Name_/i, '').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
        category: r.category ?? 'Unknown',
        blueprintId: r.blueprint_id,
        firstReceived: new Date(r.first_received_at),
        owners: [],
      });
    }
    const bp = blueprintMap.get(r.raw_name)!;
    bp.owners.push({
      discordId: r.discord_id,
      username: r.discord_username,
      avatar: avatarUrl(r.discord_id, r.discord_avatar),
      isMe: r.discord_id === myDiscordId,
      firstReceivedAt: new Date(r.first_received_at),
      times: r.times_received,
    });
    if (new Date(r.first_received_at) < bp.firstReceived) {
      bp.firstReceived = new Date(r.first_received_at);
    }
  }

  const blueprints = Array.from(blueprintMap.values());

  const branches = await getAvailableBranches();

  res.render('blueprints', {
    title: 'Blueprints',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(myDiscordId, req.session.avatar ?? null) },
    ...navLocals(req),
    branches,
    currentBranch: bpBranch,
    blueprints,
    players: playersRow.rows.map(u => ({
      discordId: u.discord_id,
      username: u.discord_username,
      isMe: u.discord_id === myDiscordId,
    })),
    categories: categoriesRow.rows.map(r => r.category),
    playerFilter: mineOnly ? 'me' : playerFilter,
    mineOnly,
    categoryFilter,
    myDiscordId,
    formatRelativeTime,
  });
}));

// ── GET /tracker/highlights ───────────────────────────────────────────────────

dashboardRouter.get('/highlights', requireAuth, asyncRoute(async (req, res) => {
  const userId = req.session.userId!;
  const page = Math.max(1, parseInt(req.query['page'] as string || '1', 10));
  const perPage = 50;
  const offset = (page - 1) * perPage;
  const branch = branchOf(req);
  const branchParam = branch || null;

  const [totalRow, rows, branches] = await Promise.all([
    pool.query<{ total: string }>(
      `SELECT COUNT(*) AS total FROM sc_tracker.highlights h
       LEFT JOIN sc_tracker.sessions ses ON ses.id = h.session_id
       WHERE h.user_id = $1 AND ($2::text IS NULL OR ses.game_branch = $2)`,
      [userId, branchParam]
    ),
    pool.query<{
      id: number; session_id: number | null; type: string; severity: string;
      occurred_at: Date; payload: Record<string, unknown>;
    }>(
      `SELECT h.id, h.session_id, h.type, h.severity, h.occurred_at, h.payload
       FROM sc_tracker.highlights h
       LEFT JOIN sc_tracker.sessions ses ON ses.id = h.session_id
       WHERE h.user_id = $1 AND ($2::text IS NULL OR ses.game_branch = $2)
       ORDER BY h.occurred_at DESC
       LIMIT $3 OFFSET $4`,
      [userId, branchParam, perPage, offset]
    ),
    getAvailableBranches(),
  ]);

  const total = parseInt(totalRow.rows[0]?.total ?? '0');
  const totalPages = Math.ceil(total / perPage);

  res.render('highlights', {
    title: 'Highlights',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    branches,
    currentBranch: branch,
    isMine: true,
    target: { username: req.session.username! },
    basePath: '/tracker/highlights',
    rows: rows.rows.map(h => {
      const d = highlightDisplay(h.type, h.payload);
      return {
        ...h,
        icon: d.icon,
        title: d.title,
        description: d.description,
        relativeTime: formatRelativeTime(new Date(h.occurred_at)),
      };
    }),
    page,
    totalPages,
  });
}));

// ── GET /tracker/highlights/global ───────────────────────────────────────────

dashboardRouter.get('/highlights/global', requireAuth, asyncRoute(async (req, res) => {
  const branch = branchOf(req);
  const branchParam = branch || null;

  const [rows, branches, heatmapRow] = await Promise.all([
    pool.query<{
      id: number; session_id: number | null; type: string; severity: string;
      occurred_at: Date; payload: Record<string, unknown>;
      discord_id: string; username: string;
    }>(
      `SELECT h.id, h.session_id, h.type, h.severity, h.occurred_at, h.payload,
              u.discord_id, u.discord_username AS username
       FROM sc_tracker.highlights h
       JOIN sc_tracker.users u ON u.id = h.user_id
       LEFT JOIN sc_tracker.sessions ses ON ses.id = h.session_id
       WHERE h.severity IN ('epic','major')
         AND u.is_banned = FALSE
         AND ($1::text IS NULL OR ses.game_branch = $1)
       ORDER BY h.occurred_at DESC
       LIMIT 100`,
      [branchParam]
    ),
    getAvailableBranches(),
    pool.query<{ dow: number; hour: number; session_count: number; user_count: number }>(`
      SELECT
        EXTRACT(DOW FROM s.started_at AT TIME ZONE 'UTC')::INTEGER AS dow,
        EXTRACT(HOUR FROM s.started_at AT TIME ZONE 'UTC')::INTEGER AS hour,
        COUNT(*)::INTEGER AS session_count,
        COUNT(DISTINCT s.user_id)::INTEGER AS user_count
      FROM sc_tracker.sessions s
      JOIN sc_tracker.users u ON u.id = s.user_id
      WHERE u.is_banned = FALSE AND s.started_at >= NOW() - INTERVAL '90 days'
      GROUP BY dow, hour
    `),
  ]);

  const orgHeatmap: Array<Array<{ sessionCount: number; userCount: number }>> =
    Array.from({ length: 7 }, () => Array.from({ length: 24 }, () => ({ sessionCount: 0, userCount: 0 })));
  for (const r of heatmapRow.rows) {
    orgHeatmap[r.dow][r.hour] = { sessionCount: r.session_count, userCount: r.user_count };
  }
  const maxHeatmapCount = Math.max(1, ...heatmapRow.rows.map(r => r.session_count));

  res.render('highlights-global', {
    title: 'Community Highlights',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    branches,
    currentBranch: branch,
    orgHeatmap,
    maxHeatmapCount,
    rows: rows.rows.map(h => {
      const d = highlightDisplay(h.type, h.payload);
      return {
        ...h,
        icon: d.icon,
        title: d.title,
        description: d.description,
        relativeTime: formatRelativeTime(new Date(h.occurred_at)),
      };
    }),
  });
}));

// ── Achievement definitions (used by profile route) ───────────────────────────

const ACHIEVEMENT_DEFS = [
  { id: 'FIRST_SESSION',   name: 'Breaking the Verse', icon: '🚀', tier: 'bronze', desc: 'Log your first session',            key: 'sessions',         goal: 1    },
  { id: 'SESSIONS_10',     name: 'Regular',            icon: '🛸', tier: 'silver', desc: '10 sessions logged',               key: 'sessions',         goal: 10   },
  { id: 'SESSIONS_50',     name: 'Veteran Pilot',      icon: '⭐', tier: 'gold',   desc: '50 sessions logged',               key: 'sessions',         goal: 50   },
  { id: 'SESSIONS_100',    name: 'Lifer',              icon: '🌟', tier: 'epic',   desc: '100 sessions logged',              key: 'sessions',         goal: 100  },
  { id: 'PLAYTIME_24H',    name: 'Day One',            icon: '⏱️', tier: 'bronze', desc: '24 hours total playtime',          key: 'hoursPlayed',      goal: 24   },
  { id: 'PLAYTIME_100H',   name: 'Hundred Hours',      icon: '⌚', tier: 'silver', desc: '100 hours played',                 key: 'hoursPlayed',      goal: 100  },
  { id: 'PLAYTIME_500H',   name: 'Tour of Duty',       icon: '🏅', tier: 'gold',   desc: '500 hours played',                 key: 'hoursPlayed',      goal: 500  },
  { id: 'CONTRACTS_10',    name: 'Hired Gun',          icon: '💼', tier: 'bronze', desc: '10 contracts completed',           key: 'contracts',        goal: 10   },
  { id: 'CONTRACTS_100',   name: 'Professional',       icon: '🎯', tier: 'silver', desc: '100 contracts completed',          key: 'contracts',        goal: 100  },
  { id: 'CONTRACTS_500',   name: 'Contract Legend',    icon: '👑', tier: 'gold',   desc: '500 contracts completed',          key: 'contracts',        goal: 500  },
  { id: 'EXPLORER_10',     name: 'Groundbreaker',      icon: '📍', tier: 'bronze', desc: '10 unique zones visited',          key: 'uniqueZones',      goal: 10   },
  { id: 'EXPLORER_30',     name: 'Pathfinder',         icon: '🗺️', tier: 'silver', desc: '30 unique zones visited',          key: 'uniqueZones',      goal: 30   },
  { id: 'EXPLORER_75',     name: 'Cartographer',       icon: '🌐', tier: 'gold',   desc: '75 unique zones visited',          key: 'uniqueZones',      goal: 75   },
  { id: 'SHIPS_5',         name: 'Spotter',            icon: '👀', tier: 'bronze', desc: '5 unique ship classes spotted',    key: 'uniqueShipClasses',goal: 5    },
  { id: 'SHIPS_20',        name: 'Ship Enthusiast',    icon: '🛩️', tier: 'silver', desc: '20 unique ship classes spotted',   key: 'uniqueShipClasses',goal: 20   },
  { id: 'MISSIONS_50',     name: 'Mission Runner',     icon: '📋', tier: 'bronze', desc: '50 missions started',              key: 'missions',         goal: 50   },
  { id: 'MISSIONS_500',    name: 'Operator',           icon: '🎖️', tier: 'silver', desc: '500 missions started',             key: 'missions',         goal: 500  },
  { id: 'BLUEPRINTS_5',    name: 'Tinkerer',           icon: '📜', tier: 'bronze', desc: '5 blueprints collected',           key: 'blueprints',       goal: 5    },
  { id: 'BLUEPRINTS_20',   name: 'Engineer',           icon: '⚙️', tier: 'gold',   desc: '20 blueprints collected',          key: 'blueprints',       goal: 20   },
] as const;

// ── GET /tracker/players/:discordId ───────────────────────────────────────────

dashboardRouter.get('/players/:discordId', requireAuth, asyncRoute(async (req, res) => {
  const targetId = req.params['discordId'];

  const [profileRow, recentSessionsRow, rankRow, heatmapRow, missionRow, shipRow] = await Promise.all([
    pool.query<{
      discord_id: string; discord_username: string; discord_avatar: string | null;
      member_since: Date; missions: string; total_playtime_secs: string;
      sessions: string; ships_lost: string; contracts: string;
      unique_zones: string; unique_ship_classes: string; blueprints: string;
    }>(`
      SELECT
        u.discord_id, u.discord_username, u.discord_avatar, u.created_at AS member_since,
        (SELECT COUNT(*) FROM sc_tracker.events WHERE user_id = u.id AND event_type = 'MISSION_START') AS missions,
        (SELECT COALESCE(SUM(duration_secs), 0) FROM sc_tracker.sessions WHERE user_id = u.id) AS total_playtime_secs,
        (SELECT COUNT(*) FROM sc_tracker.sessions WHERE user_id = u.id) AS sessions,
        (SELECT COUNT(*) FROM sc_tracker.events WHERE user_id = u.id AND event_type = 'SHIP_CLAIM') AS ships_lost,
        (SELECT COUNT(*) FROM sc_tracker.events WHERE user_id = u.id AND event_type = 'CONTRACT_COMPLETE') AS contracts,
        (SELECT COUNT(DISTINCT payload->>'notificationText') FROM sc_tracker.events WHERE user_id = u.id AND event_type = 'ZONE_ENTERED') AS unique_zones,
        (SELECT COUNT(DISTINCT payload->>'shipClass') FROM sc_tracker.events WHERE user_id = u.id AND event_type = 'SHIP_NEARBY') AS unique_ship_classes,
        (SELECT COUNT(*) FROM sc_tracker.events WHERE user_id = u.id AND event_type = 'BLUEPRINT_RECEIVED') AS blueprints
      FROM sc_tracker.users u
      WHERE u.discord_id = $1 AND u.is_banned = FALSE
    `, [targetId]),

    pool.query<{
      id: number; started_at: Date; duration_secs: number | null; mission_count: string;
    }>(`
      SELECT
        s.id, s.started_at, s.duration_secs,
        COUNT(e.id) FILTER (WHERE e.event_type = 'MISSION_START') AS mission_count
      FROM sc_tracker.sessions s
      LEFT JOIN sc_tracker.events e ON e.session_id = s.id
      WHERE s.user_id = (SELECT id FROM sc_tracker.users WHERE discord_id = $1)
      GROUP BY s.id
      ORDER BY s.started_at DESC
      LIMIT 10
    `, [targetId]),

    pool.query<{ rank: string }>(`
      WITH ranks AS (
        SELECT user_id, RANK() OVER (ORDER BY COUNT(*) DESC) AS rank
        FROM sc_tracker.events WHERE event_type = 'MISSION_START' GROUP BY user_id
      )
      SELECT rank FROM ranks
      WHERE user_id = (SELECT id FROM sc_tracker.users WHERE discord_id = $1)
    `, [targetId]),

    pool.query<{ day: string; total_secs: string; session_count: string }>(`
      SELECT
        TO_CHAR(DATE(s.started_at AT TIME ZONE 'UTC'), 'YYYY-MM-DD') AS day,
        SUM(COALESCE(s.duration_secs, 0))::TEXT AS total_secs,
        COUNT(*)::TEXT AS session_count
      FROM sc_tracker.sessions s
      WHERE s.user_id = (SELECT id FROM sc_tracker.users WHERE discord_id = $1)
        AND s.started_at >= NOW() - INTERVAL '54 weeks'
      GROUP BY DATE(s.started_at AT TIME ZONE 'UTC')
      ORDER BY day
    `, [targetId]),

    pool.query<{ mission_type: string; count: string }>(`
      SELECT
        payload->>'missionType' AS mission_type,
        COUNT(*)::TEXT AS count
      FROM sc_tracker.events
      WHERE user_id = (SELECT id FROM sc_tracker.users WHERE discord_id = $1)
        AND event_type = 'MISSION_START'
        AND payload->>'missionType' IS NOT NULL
        AND payload->>'missionType' NOT ILIKE '%FrontendHangar%'
        AND payload->>'missionType' NOT ILIKE '%/EA/%'
      GROUP BY payload->>'missionType'
      ORDER BY COUNT(*) DESC
      LIMIT 10
    `, [targetId]),

    pool.query<{ ship_class: string; count: string }>(`
      SELECT
        payload->>'shipClass' AS ship_class,
        COUNT(*)::TEXT AS count
      FROM sc_tracker.events
      WHERE user_id = (SELECT id FROM sc_tracker.users WHERE discord_id = $1)
        AND event_type = 'SHIP_NEARBY'
        AND payload->>'shipClass' IS NOT NULL
      GROUP BY payload->>'shipClass'
      ORDER BY COUNT(*) DESC
      LIMIT 12
    `, [targetId]),
  ]);

  if (!profileRow.rows[0]) { res.status(404).send('Player not found'); return; }
  const p = profileRow.rows[0];

  const badges = await fetchSessionBadges(recentSessionsRow.rows.map(s => s.id));

  const heatmapWeeks = buildHeatmapWeeks(heatmapRow.rows);

  const missionBreakdown = missionRow.rows.map(r => ({
    label: formatMissionType(r.mission_type),
    count: parseInt(r.count),
  }));
  const maxMissions = missionBreakdown.reduce((m, r) => Math.max(m, r.count), 1);

  const shipEncounters = shipRow.rows.map(r => ({
    label: formatShipClass(r.ship_class),
    rawClass: r.ship_class,
    count: parseInt(r.count),
  }));

  const profileStats = {
    sessions:          parseInt(p.sessions),
    hoursPlayed:       parseInt(p.total_playtime_secs) / 3600,
    contracts:         parseInt(p.contracts),
    missions:          parseInt(p.missions),
    uniqueZones:       parseInt(p.unique_zones || '0'),
    uniqueShipClasses: parseInt(p.unique_ship_classes || '0'),
    blueprints:        parseInt(p.blueprints || '0'),
  } as Record<string, number>;

  const achievements = ACHIEVEMENT_DEFS.map(a => {
    const val = profileStats[a.key] ?? 0;
    const earned = val >= a.goal;
    const progress = Math.min(val / a.goal, 1);
    return {
      ...a,
      earned,
      progress,
      progressLabel: earned ? 'Completed' : `${Math.floor(val).toLocaleString()} / ${a.goal.toLocaleString()}`,
    };
  });

  // T014 — schedule intelligence: when does this player log sessions?
  const scheduleRow = await pool.query<{ dow: number; hour: number; count: number }>(`
    SELECT
      EXTRACT(DOW FROM s.started_at AT TIME ZONE 'UTC')::INTEGER AS dow,
      EXTRACT(HOUR FROM s.started_at AT TIME ZONE 'UTC')::INTEGER AS hour,
      COUNT(*)::INTEGER AS count
    FROM sc_tracker.sessions s
    WHERE s.user_id = (SELECT id FROM sc_tracker.users WHERE discord_id = $1)
    GROUP BY dow, hour
    ORDER BY count DESC
    LIMIT 5
  `, [targetId]);

  const DOW_FULL = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const peakTimes = scheduleRow.rows.map(r => ({
    dow: r.dow,
    hour: r.hour,
    count: r.count,
    label: `${DOW_FULL[r.dow]} ${String(r.hour).padStart(2,'0')}:00 UTC`,
  }));

  res.render('profile', {
    title: `${p.discord_username}'s Profile`,
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    profile: {
      discordId: p.discord_id,
      username: p.discord_username,
      avatar: avatarUrl(p.discord_id, p.discord_avatar),
      memberSince: new Date(p.member_since).toLocaleDateString(),
      rank: rankRow.rows[0] ? parseInt(rankRow.rows[0].rank) : null,
      missions: parseInt(p.missions),
      totalPlaytime: formatDuration(parseInt(p.total_playtime_secs)),
      sessions: parseInt(p.sessions),
      shipsLost: parseInt(p.ships_lost),
      contracts: parseInt(p.contracts),
    },
    recentSessions: recentSessionsRow.rows.map(s => ({
      ...s,
      durationFormatted: formatDuration(s.duration_secs ?? 0),
      startedAtFormatted: new Date(s.started_at).toLocaleDateString(),
      missionCount: parseInt(s.mission_count),
      badges: badges.get(s.id) ?? [],
    })),
    heatmapWeeks,
    missionBreakdown,
    maxMissions,
    shipEncounters,
    achievements,
    peakTimes,
  });
}));

// ── GET /tracker/zones ────────────────────────────────────────────────────────

dashboardRouter.get('/zones', requireAuth, asyncRoute(async (req, res) => {
  const userId = req.session.userId!;

  const [myZonesRow, orgZonesRow] = await Promise.all([
    pool.query<{ zone_name: string; visit_count: string; first_visit: Date; last_visit: Date }>(`
      SELECT
        payload->>'notificationText' AS zone_name,
        COUNT(*)::TEXT AS visit_count,
        MIN(occurred_at) AS first_visit,
        MAX(occurred_at) AS last_visit
      FROM sc_tracker.events
      WHERE user_id = $1
        AND event_type = 'ZONE_ENTERED'
        AND payload->>'notificationText' IS NOT NULL
      GROUP BY payload->>'notificationText'
      ORDER BY COUNT(*) DESC
    `, [userId]),

    pool.query<{ zone_name: string; user_count: string }>(`
      SELECT
        payload->>'notificationText' AS zone_name,
        COUNT(DISTINCT user_id)::TEXT AS user_count
      FROM sc_tracker.events
      WHERE event_type = 'ZONE_ENTERED'
        AND payload->>'notificationText' IS NOT NULL
      GROUP BY payload->>'notificationText'
    `),
  ]);

  const orgZoneSet = new Map(orgZonesRow.rows.map(r => [r.zone_name, parseInt(r.user_count)]));
  const myZoneNames = new Set(myZonesRow.rows.map(r => r.zone_name));

  const zones = myZonesRow.rows.map(r => ({
    zoneName: r.zone_name,
    visitCount: parseInt(r.visit_count),
    firstVisit: new Date(r.first_visit).toLocaleDateString(),
    lastVisit: new Date(r.last_visit).toLocaleDateString(),
    isExclusive: (orgZoneSet.get(r.zone_name) ?? 0) <= 1,
  }));

  const myExclusiveCount = zones.filter(z => z.isExclusive).length;

  res.render('zones', {
    title: 'Zone Atlas',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    zones,
    myZoneCount: myZonesRow.rows.length,
    orgZoneCount: orgZonesRow.rows.length,
    myExclusiveCount,
  });
}));

// ── GET /tracker/export/sessions.csv ──────────────────────────────────────────

dashboardRouter.get('/export/sessions.csv', requireAuth, asyncRoute(async (req, res) => {
  const userId = req.session.userId!;

  const rows = await pool.query<{
    id: number; started_at: Date; ended_at: Date | null; duration_secs: number | null;
    character_name: string; game_version: string | null; game_branch: string | null;
    missions: string; contracts: string; zones: string; ships_lost: string;
  }>(`
    SELECT
      s.id, s.started_at, s.ended_at, s.duration_secs, s.character_name,
      s.game_version, s.game_branch,
      COUNT(e.id) FILTER (WHERE e.event_type = 'MISSION_START')::TEXT    AS missions,
      COUNT(e.id) FILTER (WHERE e.event_type = 'CONTRACT_COMPLETE')::TEXT AS contracts,
      COUNT(e.id) FILTER (WHERE e.event_type = 'ZONE_ENTERED')::TEXT      AS zones,
      COUNT(e.id) FILTER (WHERE e.event_type = 'SHIP_CLAIM')::TEXT        AS ships_lost
    FROM sc_tracker.sessions s
    LEFT JOIN sc_tracker.events e ON e.session_id = s.id
    WHERE s.user_id = $1
    GROUP BY s.id
    ORDER BY s.started_at DESC
  `, [userId]);

  const esc = (v: string | number | null | undefined) => {
    const s = String(v ?? '');
    return s.includes(',') || s.includes('"') || s.includes('\n')
      ? `"${s.replace(/"/g, '""')}"`
      : s;
  };

  const header = 'id,started_at,ended_at,duration_mins,character_name,game_version,missions,contracts,zones_entered,ships_lost';
  const csvRows = rows.rows.map(r => [
    r.id,
    r.started_at ? new Date(r.started_at).toISOString() : '',
    r.ended_at ? new Date(r.ended_at).toISOString() : '',
    r.duration_secs != null ? Math.round(r.duration_secs / 60) : '',
    esc(r.character_name),
    esc(formatGameVersion(r.game_version, r.game_branch)),
    r.missions, r.contracts, r.zones, r.ships_lost,
  ].join(','));

  const csv = [header, ...csvRows].join('\r\n');
  const filename = `sc-tracker-sessions-${new Date().toISOString().slice(0, 10)}.csv`;
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.send(csv);
}));

// ── Season helpers ─────────────────────────────────────────────────────────────

const METRIC_LABELS: Record<string, string> = {
  playtime: 'Playtime', contracts: 'Contracts', missions: 'Missions',
  zones: 'Unique Zones', sessions: 'Sessions',
};

function timeUntil(date: Date): string {
  const ms = date.getTime() - Date.now();
  if (ms <= 0) return 'ended';
  const d = Math.floor(ms / 86400000);
  const h = Math.floor((ms % 86400000) / 3600000);
  if (d > 0) return `${d}d ${h}h`;
  return `${h}h`;
}

function formatSeasonValue(metric: string, value: number): string {
  if (metric === 'playtime') return formatDuration(value);
  return value.toLocaleString();
}

function seasonMetricQuery(metric: string): string {
  switch (metric) {
    case 'playtime':
      return `SELECT u.discord_id, u.discord_username, u.discord_avatar,
                SUM(COALESCE(s.duration_secs, 0))::BIGINT AS value
              FROM sc_tracker.sessions s
              JOIN sc_tracker.users u ON u.id = s.user_id
              WHERE u.is_banned = FALSE
                AND s.started_at >= $1 AND ($2::TIMESTAMPTZ IS NULL OR s.started_at <= $2)
              GROUP BY u.id, u.discord_id, u.discord_username, u.discord_avatar
              ORDER BY value DESC LIMIT 25`;
    case 'contracts':
      return `SELECT u.discord_id, u.discord_username, u.discord_avatar,
                COUNT(e.id)::BIGINT AS value
              FROM sc_tracker.events e
              JOIN sc_tracker.users u ON u.id = e.user_id
              WHERE u.is_banned = FALSE AND e.event_type = 'CONTRACT_COMPLETE'
                AND e.occurred_at >= $1 AND ($2::TIMESTAMPTZ IS NULL OR e.occurred_at <= $2)
              GROUP BY u.id, u.discord_id, u.discord_username, u.discord_avatar
              ORDER BY value DESC LIMIT 25`;
    case 'missions':
      return `SELECT u.discord_id, u.discord_username, u.discord_avatar,
                COUNT(e.id)::BIGINT AS value
              FROM sc_tracker.events e
              JOIN sc_tracker.users u ON u.id = e.user_id
              WHERE u.is_banned = FALSE AND e.event_type = 'MISSION_START'
                AND e.occurred_at >= $1 AND ($2::TIMESTAMPTZ IS NULL OR e.occurred_at <= $2)
              GROUP BY u.id, u.discord_id, u.discord_username, u.discord_avatar
              ORDER BY value DESC LIMIT 25`;
    case 'zones':
      return `SELECT u.discord_id, u.discord_username, u.discord_avatar,
                COUNT(DISTINCT e.payload->>'notificationText')::BIGINT AS value
              FROM sc_tracker.events e
              JOIN sc_tracker.users u ON u.id = e.user_id
              WHERE u.is_banned = FALSE AND e.event_type = 'ZONE_ENTERED'
                AND e.occurred_at >= $1 AND ($2::TIMESTAMPTZ IS NULL OR e.occurred_at <= $2)
              GROUP BY u.id, u.discord_id, u.discord_username, u.discord_avatar
              ORDER BY value DESC LIMIT 25`;
    default: // sessions
      return `SELECT u.discord_id, u.discord_username, u.discord_avatar,
                COUNT(s.id)::BIGINT AS value
              FROM sc_tracker.sessions s
              JOIN sc_tracker.users u ON u.id = s.user_id
              WHERE u.is_banned = FALSE
                AND s.started_at >= $1 AND ($2::TIMESTAMPTZ IS NULL OR s.started_at <= $2)
              GROUP BY u.id, u.discord_id, u.discord_username, u.discord_avatar
              ORDER BY value DESC LIMIT 25`;
  }
}

type SeasonRow = { id: number; name: string; description: string | null; metric: string; started_at: Date; ended_at: Date | null };
type LBRow = { discord_id: string; discord_username: string; discord_avatar: string | null; value: string };

async function fetchSeasonTop3(s: SeasonRow): Promise<Array<{ discordId: string; username: string; avatar: string; value: number; valueFormatted: string }>> {
  const endParam = s.ended_at ? s.ended_at : null;
  const rows = await pool.query<LBRow>(seasonMetricQuery(s.metric), [s.started_at, endParam]);
  return rows.rows.slice(0, 3).map(r => ({
    discordId: r.discord_id,
    username: r.discord_username,
    avatar: avatarUrl(r.discord_id, r.discord_avatar ?? null),
    value: parseInt(r.value ?? '0'),
    valueFormatted: formatSeasonValue(s.metric, parseInt(r.value ?? '0')),
  }));
}

// ── GET /tracker/seasons ──────────────────────────────────────────────────────

dashboardRouter.get('/seasons', requireAuth, asyncRoute(async (req, res) => {
  const allSeasons = await pool.query<SeasonRow>(`
    SELECT id, name, description, metric, started_at, ended_at
    FROM sc_tracker.seasons ORDER BY started_at DESC
  `);

  const now = new Date();
  const activeSeasons: typeof allSeasons.rows = [];
  const pastSeasons: typeof allSeasons.rows = [];
  for (const s of allSeasons.rows) {
    if (!s.ended_at || new Date(s.ended_at) > now) activeSeasons.push(s);
    else pastSeasons.push(s);
  }

  const [activeFormatted, pastFormatted] = await Promise.all([
    Promise.all(activeSeasons.map(async s => ({
      id: s.id, name: s.name, description: s.description, metric: s.metric,
      metricLabel: METRIC_LABELS[s.metric] ?? s.metric,
      startedAtFormatted: new Date(s.started_at).toLocaleDateString(),
      endedAtFormatted: s.ended_at ? new Date(s.ended_at).toLocaleDateString() : null,
      isActive: true,
      timeRemaining: s.ended_at ? timeUntil(new Date(s.ended_at)) : 'ongoing',
      topPlayers: await fetchSeasonTop3(s),
    }))),
    Promise.all(pastSeasons.map(async s => ({
      id: s.id, name: s.name, description: s.description, metric: s.metric,
      metricLabel: METRIC_LABELS[s.metric] ?? s.metric,
      startedAtFormatted: new Date(s.started_at).toLocaleDateString(),
      endedAtFormatted: s.ended_at ? new Date(s.ended_at).toLocaleDateString() : null,
      isActive: false,
      timeRemaining: null,
      topPlayers: await fetchSeasonTop3(s),
    }))),
  ]);

  res.render('seasons', {
    title: 'Seasons',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    activeSeasons: activeFormatted,
    pastSeasons: pastFormatted,
  });
}));

// ── GET /tracker/seasons/:id ──────────────────────────────────────────────────

dashboardRouter.get('/seasons/:id', requireAuth, asyncRoute(async (req, res) => {
  const id = parseInt(req.params['id'] ?? '', 10);
  if (isNaN(id)) return void res.redirect('/tracker/seasons');

  const sRow = await pool.query<SeasonRow>(
    `SELECT id, name, description, metric, started_at, ended_at FROM sc_tracker.seasons WHERE id = $1`,
    [id]
  );
  if (sRow.rows.length === 0) return void res.redirect('/tracker/seasons');
  const s = sRow.rows[0]!;

  const endParam = s.ended_at ? s.ended_at : null;
  const lbRow = await pool.query<LBRow>(seasonMetricQuery(s.metric), [s.started_at, endParam]);

  const now = new Date();
  const isActive = !s.ended_at || new Date(s.ended_at) > now;

  res.render('season-detail', {
    title: s.name,
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    season: {
      id: s.id, name: s.name, description: s.description, metric: s.metric,
      metricLabel: METRIC_LABELS[s.metric] ?? s.metric,
      startedAtFormatted: new Date(s.started_at).toLocaleDateString(),
      endedAtFormatted: s.ended_at ? new Date(s.ended_at).toLocaleDateString() : null,
      isActive,
      timeRemaining: s.ended_at ? timeUntil(new Date(s.ended_at)) : 'ongoing',
    },
    leaderboard: lbRow.rows.map(r => ({
      discordId: r.discord_id,
      username: r.discord_username,
      avatar: avatarUrl(r.discord_id, r.discord_avatar ?? null),
      value: parseInt(r.value ?? '0'),
      valueFormatted: formatSeasonValue(s.metric, parseInt(r.value ?? '0')),
    })),
  });
}));

// ── GET /tracker/challenges ───────────────────────────────────────────────────

dashboardRouter.get('/challenges', requireAuth, asyncRoute(async (req, res) => {
  const now = new Date();
  const dayOfWeek = now.getUTCDay(); // 0=Sun
  const daysFromMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
  const weekStart = new Date(now);
  weekStart.setUTCDate(now.getUTCDate() - daysFromMonday);
  weekStart.setUTCHours(0, 0, 0, 0);
  const weekEnd = new Date(weekStart);
  weekEnd.setUTCDate(weekStart.getUTCDate() + 7);

  const msToReset = weekEnd.getTime() - now.getTime();
  const dToReset = Math.floor(msToReset / 86400000);
  const hToReset = Math.floor((msToReset % 86400000) / 3600000);
  const resetLabel = dToReset > 0 ? `${dToReset}d ${hToReset}h` : `${hToReset}h`;

  const opts = { start: weekStart };

  type ChRow = { discord_id: string; discord_username: string; discord_avatar: string | null; value: string };

  const [contractsRow, playtimeRow, missionsRow, sessionsRow, zonesRow] = await Promise.all([
    pool.query<ChRow>(`
      SELECT u.discord_id, u.discord_username, u.discord_avatar, COUNT(e.id)::TEXT AS value
      FROM sc_tracker.events e JOIN sc_tracker.users u ON u.id = e.user_id
      WHERE u.is_banned = FALSE AND e.event_type = 'CONTRACT_COMPLETE' AND e.occurred_at >= $1
      GROUP BY u.id, u.discord_id, u.discord_username, u.discord_avatar
      ORDER BY COUNT(e.id) DESC LIMIT 5
    `, [opts.start]),
    pool.query<ChRow>(`
      SELECT u.discord_id, u.discord_username, u.discord_avatar,
             SUM(COALESCE(s.duration_secs,0))::TEXT AS value
      FROM sc_tracker.sessions s JOIN sc_tracker.users u ON u.id = s.user_id
      WHERE u.is_banned = FALSE AND s.started_at >= $1
      GROUP BY u.id, u.discord_id, u.discord_username, u.discord_avatar
      ORDER BY SUM(COALESCE(s.duration_secs,0)) DESC LIMIT 5
    `, [opts.start]),
    pool.query<ChRow>(`
      SELECT u.discord_id, u.discord_username, u.discord_avatar, COUNT(e.id)::TEXT AS value
      FROM sc_tracker.events e JOIN sc_tracker.users u ON u.id = e.user_id
      WHERE u.is_banned = FALSE AND e.event_type = 'MISSION_START' AND e.occurred_at >= $1
      GROUP BY u.id, u.discord_id, u.discord_username, u.discord_avatar
      ORDER BY COUNT(e.id) DESC LIMIT 5
    `, [opts.start]),
    pool.query<ChRow>(`
      SELECT u.discord_id, u.discord_username, u.discord_avatar, COUNT(s.id)::TEXT AS value
      FROM sc_tracker.sessions s JOIN sc_tracker.users u ON u.id = s.user_id
      WHERE u.is_banned = FALSE AND s.started_at >= $1
      GROUP BY u.id, u.discord_id, u.discord_username, u.discord_avatar
      ORDER BY COUNT(s.id) DESC LIMIT 5
    `, [opts.start]),
    pool.query<ChRow>(`
      SELECT u.discord_id, u.discord_username, u.discord_avatar,
             COUNT(DISTINCT e.payload->>'notificationText')::TEXT AS value
      FROM sc_tracker.events e JOIN sc_tracker.users u ON u.id = e.user_id
      WHERE u.is_banned = FALSE AND e.event_type = 'ZONE_ENTERED' AND e.occurred_at >= $1
      GROUP BY u.id, u.discord_id, u.discord_username, u.discord_avatar
      ORDER BY COUNT(DISTINCT e.payload->>'notificationText') DESC LIMIT 5
    `, [opts.start]),
  ]);

  const fmtEntries = (rows: ChRow[], fmt: (v: number) => string) =>
    rows.map(r => ({
      discordId: r.discord_id,
      username: r.discord_username,
      avatar: avatarUrl(r.discord_id, r.discord_avatar ?? null),
      value: parseInt(r.value ?? '0'),
      valueFormatted: fmt(parseInt(r.value ?? '0')),
    }));

  const weekLabel = weekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' })
    + ' – ' + new Date(weekEnd.getTime() - 1).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });

  res.render('challenges', {
    title: 'Weekly Challenges',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    weekLabel,
    resetLabel,
    challenges: [
      { icon: '📜', title: 'Top Operator', desc: 'Most contracts completed this week',
        entries: fmtEntries(contractsRow.rows, v => v.toLocaleString() + ' contracts') },
      { icon: '⏱️', title: 'Marathon Pilot', desc: 'Most total playtime this week',
        entries: fmtEntries(playtimeRow.rows, formatDuration) },
      { icon: '🎯', title: 'Mission Master', desc: 'Most missions started this week',
        entries: fmtEntries(missionsRow.rows, v => v.toLocaleString() + ' missions') },
      { icon: '🛸', title: 'Frequent Flyer', desc: 'Most sessions logged this week',
        entries: fmtEntries(sessionsRow.rows, v => v.toLocaleString() + ' sessions') },
      { icon: '🗺️', title: 'Zone Explorer', desc: 'Most unique zones visited this week',
        entries: fmtEntries(zonesRow.rows, v => v.toLocaleString() + ' zones') },
    ],
  });
}));

// ── POST /tracker/admin/seasons ───────────────────────────────────────────────

dashboardRouter.post('/admin/seasons', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const { name, description, metric, started_at, ended_at } = req.body as Record<string, string>;
  const validMetrics = ['playtime', 'contracts', 'missions', 'zones', 'sessions'];
  if (!name?.trim() || !started_at || !validMetrics.includes(metric)) {
    return void res.redirect('/tracker/admin');
  }
  await pool.query(
    `INSERT INTO sc_tracker.seasons (name, description, metric, started_at, ended_at, created_by)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [name.trim(), description?.trim() || null, metric, new Date(started_at),
     ended_at ? new Date(ended_at) : null, req.session.userId!]
  );
  console.log(`[admin] created season "${name}" by ${req.session.username}`);
  res.redirect('/tracker/seasons');
}));

// ── POST /tracker/admin/seasons/:id/delete ────────────────────────────────────

dashboardRouter.post('/admin/seasons/:id/delete', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const id = parseInt(req.params['id'] ?? '', 10);
  if (!isNaN(id)) {
    await pool.query(`DELETE FROM sc_tracker.seasons WHERE id = $1`, [id]);
    console.log(`[admin] deleted season ${id} by ${req.session.username}`);
  }
  res.redirect('/tracker/seasons');
}));

// ── GET /tracker/sse — Server-Sent Events for live community feed ─────────────

dashboardRouter.get('/sse', requireAuth, (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  // Keepalive comment every 25s to prevent proxy timeout
  const keepalive = setInterval(() => {
    try { res.write(': keepalive\n\n'); } catch { clearInterval(keepalive); }
  }, 25_000);

  liveBroadcaster.addClient(res);
  req.on('close', () => clearInterval(keepalive));
});

// ── GET /tracker/settings ─────────────────────────────────────────────────────

dashboardRouter.get('/settings', requireAuth, asyncRoute(async (req, res) => {
  const row = await pool.query<{ discord_webhook_url: string | null }>(
    `SELECT discord_webhook_url FROM sc_tracker.users WHERE id = $1`,
    [req.session.userId!]
  );
  const flash = (req.session as any)['flash'] as string | undefined;
  delete (req.session as any)['flash'];
  res.render('settings', {
    title: 'Settings',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    webhookUrl: row.rows[0]?.discord_webhook_url ?? null,
    flash: flash ?? null,
  });
}));

// ── POST /tracker/settings ────────────────────────────────────────────────────

dashboardRouter.post('/settings', requireAuth, asyncRoute(async (req, res) => {
  const clearWebhook = req.body['clear_webhook'] === '1';
  const rawUrl = String(req.body['discord_webhook_url'] ?? '').trim();
  let webhookUrl: string | null = null;

  if (!clearWebhook && rawUrl) {
    try {
      const parsed = new URL(rawUrl);
      if (parsed.hostname === 'discord.com' || parsed.hostname === 'discordapp.com') {
        webhookUrl = rawUrl;
      }
    } catch { /* invalid URL — leave null */ }
  }

  await pool.query(
    `UPDATE sc_tracker.users SET discord_webhook_url = $1 WHERE id = $2`,
    [webhookUrl, req.session.userId!]
  );
  (req.session as any)['flash'] = clearWebhook ? 'Webhook removed.' : webhookUrl ? 'Settings saved!' : 'Invalid webhook URL — must be a discord.com webhook.';
  res.redirect('/tracker/settings');
}));

// ── GET /tracker/wrapped/:yearMonth ───────────────────────────────────────────

const MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December'];

dashboardRouter.get('/wrapped/:yearMonth', requireAuth, asyncRoute(async (req, res) => {
  const match = String(req.params['yearMonth'] ?? '').match(/^(\d{4})-(\d{2})$/);
  if (!match) return void res.redirect('/tracker');

  const year  = parseInt(match[1]!);
  const month = parseInt(match[2]!);
  if (month < 1 || month > 12) return void res.redirect('/tracker');

  const userId = req.session.userId!;
  const periodStart = new Date(Date.UTC(year, month - 1, 1));
  const periodEnd   = new Date(Date.UTC(year, month, 1));
  const now = new Date();
  const isFuture = periodStart > now;

  const prevD = new Date(Date.UTC(year, month - 2, 1));
  const nextD = new Date(Date.UTC(year, month, 1));
  const prevMonth = `${prevD.getUTCFullYear()}-${String(prevD.getUTCMonth() + 1).padStart(2,'0')}`;
  const nextMonth = `${nextD.getUTCFullYear()}-${String(nextD.getUTCMonth() + 1).padStart(2,'0')}`;
  const periodLabel    = `${MONTH_NAMES[month - 1]} ${year}`;
  const prevMonthLabel = `${MONTH_NAMES[prevD.getUTCMonth()]} ${prevD.getUTCFullYear()}`;
  const nextMonthLabel = `${MONTH_NAMES[nextD.getUTCMonth()]} ${nextD.getUTCFullYear()}`;

  const [statsRow, shipsRow, zonesRow, highlightsRow] = await Promise.all([
    pool.query<{ sessions: string; playtime_secs: string; missions: string; contracts: string; ships_lost: string; unique_zones: string }>(`
      WITH sid AS (
        SELECT id FROM sc_tracker.sessions WHERE user_id = $1 AND started_at >= $2 AND started_at < $3
      )
      SELECT
        (SELECT COUNT(*) FROM sid)                                                                 AS sessions,
        (SELECT COALESCE(SUM(duration_secs),0) FROM sc_tracker.sessions WHERE id IN (SELECT id FROM sid)) AS playtime_secs,
        (SELECT COUNT(*) FROM sc_tracker.events WHERE session_id IN (SELECT id FROM sid) AND event_type = 'MISSION_START') AS missions,
        (SELECT COUNT(*) FROM sc_tracker.events WHERE session_id IN (SELECT id FROM sid) AND event_type = 'CONTRACT_COMPLETE') AS contracts,
        (SELECT COUNT(*) FROM sc_tracker.events WHERE session_id IN (SELECT id FROM sid) AND event_type = 'SHIP_CLAIM') AS ships_lost,
        (SELECT COUNT(DISTINCT payload->>'notificationText') FROM sc_tracker.events WHERE session_id IN (SELECT id FROM sid) AND event_type = 'ZONE_ENTERED') AS unique_zones
    `, [userId, periodStart, periodEnd]),

    pool.query<{ ship_class: string; count: string }>(`
      SELECT payload->>'shipClass' AS ship_class, COUNT(*)::TEXT AS count
      FROM sc_tracker.events
      WHERE user_id = $1 AND event_type = 'SHIP_NEARBY'
        AND occurred_at >= $2 AND occurred_at < $3
        AND payload->>'shipClass' IS NOT NULL
      GROUP BY payload->>'shipClass'
      ORDER BY count DESC LIMIT 5
    `, [userId, periodStart, periodEnd]),

    pool.query<{ zone_name: string; count: string }>(`
      SELECT payload->>'notificationText' AS zone_name, COUNT(*)::TEXT AS count
      FROM sc_tracker.events
      WHERE user_id = $1 AND event_type = 'ZONE_ENTERED'
        AND occurred_at >= $2 AND occurred_at < $3
        AND payload->>'notificationText' IS NOT NULL
      GROUP BY payload->>'notificationText'
      ORDER BY count DESC LIMIT 5
    `, [userId, periodStart, periodEnd]),

    pool.query<{ type: string; severity: string; payload: Record<string, unknown> }>(`
      SELECT type, severity, payload FROM sc_tracker.highlights
      WHERE user_id = $1 AND occurred_at >= $2 AND occurred_at < $3
        AND severity IN ('epic','major')
      ORDER BY occurred_at DESC LIMIT 6
    `, [userId, periodStart, periodEnd]),
  ]);

  const st = statsRow.rows[0];
  res.render('wrapped', {
    title: `${req.session.username}'s ${periodLabel} Wrapped`,
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    username: req.session.username!,
    periodLabel,
    prevMonth,
    nextMonth,
    prevMonthLabel,
    nextMonthLabel,
    isFuture,
    stats: {
      sessions:    parseInt(st?.sessions ?? '0'),
      playtime:    formatDuration(parseInt(st?.playtime_secs ?? '0')),
      missions:    parseInt(st?.missions ?? '0'),
      contracts:   parseInt(st?.contracts ?? '0'),
      shipsLost:   parseInt(st?.ships_lost ?? '0'),
      uniqueZones: parseInt(st?.unique_zones ?? '0'),
    },
    topShips: shipsRow.rows.map(r => ({ label: formatShipClass(r.ship_class), count: parseInt(r.count) })),
    topZones: zonesRow.rows.map(r => ({ name: r.zone_name, count: parseInt(r.count) })),
    highlights: highlightsRow.rows.map(r => {
      const d = highlightDisplay(r.type, r.payload);
      return { icon: d.icon, title: d.title, description: d.description };
    }),
  });
}));

// ── GET /tracker/setup ────────────────────────────────────────────────────────

dashboardRouter.get('/setup', requireAuth, (req: Request, res: Response) => {
  res.render('setup', {
    title: 'Setup',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
  });
});

// ── GET /tracker/download/agent ───────────────────────────────────────────────

dashboardRouter.get('/download/agent', requireAuth, (_req: Request, res: Response) => {
  res.redirect('/downloads/agent');
});

// ── POST /tracker/admin/seal-orphans ─────────────────────────────────────────

dashboardRouter.post('/admin/seal-orphans', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const result = await pool.query(`
    WITH open_sessions AS (
      SELECT id, started_at FROM sc_tracker.sessions
      WHERE duration_secs IS NULL AND started_at < NOW() - INTERVAL '5 minutes'
    ),
    last_events AS (
      SELECT session_id, MAX(occurred_at) AS last_event
      FROM sc_tracker.events
      WHERE session_id IN (SELECT id FROM open_sessions)
      GROUP BY session_id
    )
    UPDATE sc_tracker.sessions s
    SET
      ended_at      = COALESCE(le.last_event, os.started_at),
      duration_secs = GREATEST(0, EXTRACT(EPOCH FROM (COALESCE(le.last_event, os.started_at) - os.started_at))::INTEGER)
    FROM open_sessions os
    LEFT JOIN last_events le ON le.session_id = os.id
    WHERE s.id = os.id
  `);
  console.log(`[admin] seal-orphans: sealed ${result.rowCount} session(s) by ${req.session.username}`);
  res.redirect('/tracker/admin');
}));

// ── GET /tracker/admin ────────────────────────────────────────────────────────
// God-eye view: all events across all users. Only accessible to ADMIN_DISCORD_IDS.

const NOISE_EVENT_TYPES = ['ATTACHMENT_RECEIVED', 'MISSION_CONTRACT'];
const SYSTEM_MISSION_PATTERNS = ['FrontendHangar', '/EA/'];

dashboardRouter.get('/admin', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const typeFilter   = (req.query['type'] as string) || 'all';
  const showNoise    = req.query['noise'] === '1';
  const page         = Math.max(1, parseInt(req.query['page'] as string || '1', 10));
  const perPage      = 50;
  const offset       = (page - 1) * perPage;
  const branch       = branchOf(req);
  const branchParam  = branch || null;

  // Build WHERE clause (always qualifies columns with e.)
  const conditions: string[] = [];
  const params: unknown[]    = [branchParam]; // $1 = branch

  conditions.push(`($1::text IS NULL OR e.session_id IN (SELECT id FROM sc_tracker.sessions WHERE game_branch = $1))`);

  if (!showNoise) {
    conditions.push(`e.event_type NOT IN (${NOISE_EVENT_TYPES.map((_, i) => `$${params.length + i + 1}`).join(',')})`);
    params.push(...NOISE_EVENT_TYPES);
    const p = params.length;
    conditions.push(`NOT (e.event_type = 'MISSION_START' AND (e.payload->>'missionType' LIKE $${p+1} OR e.payload->>'missionType' LIKE $${p+2}))`);
    params.push(`%${SYSTEM_MISSION_PATTERNS[0]}%`, `%${SYSTEM_MISSION_PATTERNS[1]}%`);
  }
  if (typeFilter !== 'all') {
    conditions.push(`e.event_type = $${params.length + 1}`);
    params.push(typeFilter);
  }

  const where = 'WHERE ' + conditions.join(' AND ');

  const [eventsRow, countRow, usersRow, eventTypesRow, activeRow, orphanRow, seasonsRow] = await Promise.all([
    pool.query<{
      id: number; event_type: string; payload: Record<string,unknown>;
      occurred_at: Date; discord_username: string; discord_id: string; session_id: number | null;
    }>(`
      SELECT e.id, e.event_type, e.payload, e.occurred_at, e.session_id,
             u.discord_username, u.discord_id
      FROM sc_tracker.events e
      JOIN sc_tracker.users u ON u.id = e.user_id
      ${where}
      ORDER BY e.occurred_at DESC
      LIMIT ${perPage} OFFSET ${offset}
    `, params),

    pool.query<{ total: string }>(`
      SELECT COUNT(*) AS total FROM sc_tracker.events e JOIN sc_tracker.users u ON u.id = e.user_id ${where}
    `, params),

    pool.query<{
      discord_id: string; discord_username: string; discord_avatar: string | null;
      event_count: string; session_count: string; last_seen: Date | null; is_banned: boolean;
    }>(`
      SELECT u.discord_id, u.discord_username, u.discord_avatar, u.is_banned,
             COUNT(DISTINCT e.id) AS event_count,
             COUNT(DISTINCT s.id) AS session_count,
             MAX(e.occurred_at) AS last_seen
      FROM sc_tracker.users u
      LEFT JOIN sc_tracker.events e ON e.user_id = u.id
      LEFT JOIN sc_tracker.sessions s ON s.user_id = u.id
      GROUP BY u.id ORDER BY last_seen DESC NULLS LAST
    `),

    pool.query<{ event_type: string; cnt: string }>(`
      SELECT event_type, COUNT(*) AS cnt
      FROM sc_tracker.events GROUP BY event_type ORDER BY cnt DESC
    `),

    // "Live" = open session (no SESSION_END) AND most recent event within
    // the last 5 minutes. Orphaned crash sessions get filtered out.
    pool.query<{
      discord_username: string; started_at: Date; session_id: number;
      last_event: Date | null; event_count: string;
    }>(`
      SELECT u.discord_username, s.started_at, s.id AS session_id,
             le.last_event, le.event_count
      FROM sc_tracker.sessions s
      JOIN sc_tracker.users u ON u.id = s.user_id
      JOIN LATERAL (
        SELECT MAX(occurred_at) AS last_event, COUNT(*) AS event_count
        FROM sc_tracker.events WHERE session_id = s.id
      ) le ON TRUE
      WHERE s.duration_secs IS NULL
        AND le.last_event > NOW() - INTERVAL '5 minutes'
      ORDER BY le.last_event DESC
      LIMIT 10
    `),

    // Count of orphaned open sessions (no SESSION_END, no recent activity)
    // — useful to surface so we can clean them up.
    pool.query<{ orphan_count: string }>(`
      SELECT COUNT(*) AS orphan_count
      FROM sc_tracker.sessions s
      WHERE s.duration_secs IS NULL
        AND COALESCE(
          (SELECT MAX(occurred_at) FROM sc_tracker.events WHERE session_id = s.id),
          s.started_at
        ) < NOW() - INTERVAL '5 minutes'
    `),

    pool.query<{ id: number; name: string; metric: string; started_at: Date; ended_at: Date | null }>(
      `SELECT id, name, metric, started_at, ended_at FROM sc_tracker.seasons ORDER BY started_at DESC`
    ),
  ]);

  const total      = parseInt(countRow.rows[0]?.total ?? '0');
  const totalPages = Math.ceil(total / perPage);

  res.render('admin', {
    title: 'Admin — God Eye',
    theme: theme(req),
    user: { username: req.session.username!, avatar: avatarUrl(req.session.discordId!, req.session.avatar ?? null) },
    ...navLocals(req),
    events: eventsRow.rows.map(e => ({
      ...e,
      description: eventDescription(e.event_type, e.payload),
      category: eventCategory(e.event_type),
      timeFormatted: new Date(e.occurred_at).toLocaleString(),
      relativeTime: formatRelativeTime(new Date(e.occurred_at)),
      isNoise: NOISE_EVENT_TYPES.includes(e.event_type) ||
               (e.event_type === 'MISSION_START' &&
                SYSTEM_MISSION_PATTERNS.some(p => String(e.payload['missionType'] ?? '').includes(p))),
    })),
    users: usersRow.rows.map(u => ({
      ...u,
      avatar: avatarUrl(u.discord_id, u.discord_avatar),
      lastSeen: u.last_seen ? formatRelativeTime(new Date(u.last_seen)) : 'never',
      eventCount: parseInt(u.event_count),
      sessionCount: parseInt(u.session_count),
    })),
    activeSessions: activeRow.rows.map(s => ({
      ...s,
      startedAtFormatted: formatRelativeTime(new Date(s.started_at)),
      lastEventFormatted: s.last_event ? formatRelativeTime(new Date(s.last_event)) : 'never',
      eventCount: parseInt(s.event_count),
    })),
    orphanCount: parseInt(orphanRow.rows[0]?.orphan_count ?? '0'),
    eventTypes: eventTypesRow.rows,
    branches: await getAvailableBranches(),
    currentBranch: branch,
    typeFilter,
    showNoise,
    page,
    totalPages,
    total,
    seasons: seasonsRow.rows.map(s => {
      const now2 = new Date();
      return {
        ...s,
        startedAtFormatted: new Date(s.started_at).toLocaleDateString(),
        isActive: !s.ended_at || new Date(s.ended_at) > now2,
      };
    }),
  });
}));

// ── POST /tracker/admin/ban — toggle ban status ───────────────────────────────

dashboardRouter.post('/admin/ban', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const targetDiscordId = String(req.body['discordId'] ?? '');
  const banned = req.body['banned'] === '1' || req.body['banned'] === 'true';
  if (!targetDiscordId) { res.status(400).send('Missing discordId'); return; }

  // Bumping token_version when banning revokes any active agent token immediately.
  const upd = await pool.query<{ id: number }>(
    `UPDATE sc_tracker.users
       SET is_banned = $2,
           token_version = CASE WHEN $2 THEN token_version + 1 ELSE token_version END,
           updated_at = NOW()
     WHERE discord_id = $1
     RETURNING id`,
    [targetDiscordId, banned]
  );
  // If we banned them, also force-disconnect any active WS they have right now.
  if (banned && upd.rows[0]) {
    const kicked = revokeUserSockets(upd.rows[0].id, 'Account suspended');
    if (kicked > 0) console.log(`[admin] banned ${targetDiscordId}: kicked ${kicked} active socket(s)`);
  }
  res.redirect('/tracker/admin');
}));

// ── POST /tracker/theme ───────────────────────────────────────────────────────

dashboardRouter.post('/theme', requireAuth, (req: Request, res: Response) => {
  const t = req.body['theme'];
  const redirect = req.body['redirect'] as string | undefined;
  if (t === 'dark-purple' || t === 'dark-amber') {
    req.session.theme = t;
  }
  // Validate redirect to prevent open redirect
  const target = redirect?.startsWith('/tracker') ? redirect : '/tracker';
  res.redirect(target);
});
