import { Router, Request, Response } from 'express';
import https from 'https';
import crypto from 'crypto';
import { pool } from '../db/client';
import { generateToken, verifyToken } from '../auth/tokens';
import { revokeUserSockets } from '../ws/handler';
import '../middleware/session'; // load SessionData augmentation

export const authRouter = Router();

const DISCORD_API = 'https://discord.com/api/v10';
const CLIENT_ID = process.env['DISCORD_CLIENT_ID']!;
const CLIENT_SECRET = process.env['DISCORD_CLIENT_SECRET']!;
const REDIRECT_URI = process.env['DISCORD_REDIRECT_URI']!;

declare module 'express-session' {
  interface SessionData {
    oauthNonce?: string; // kept for backwards compat — no longer written
  }
}

const HMAC_SECRET = process.env['SESSION_SECRET']!;

function signNonce(nonce: string): string {
  return crypto.createHmac('sha256', HMAC_SECRET).update(nonce).digest('base64url');
}

function verifyNonceSig(nonce: string, sig: string): boolean {
  const expected = signNonce(nonce);
  try {
    return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
  } catch {
    return false;
  }
}

/** Minimal HTTPS POST/GET helper to avoid ESM/CJS issues with node-fetch v3. */
function httpsRequest(
  url: string,
  options: { method?: string; headers?: Record<string, string>; body?: string }
): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const reqOptions = {
      hostname: parsed.hostname,
      path: parsed.pathname + parsed.search,
      method: options.method ?? 'GET',
      headers: options.headers ?? {},
    };
    const req = https.request(reqOptions, (res) => {
      const chunks: Buffer[] = [];
      res.on('data', (chunk: Buffer) => chunks.push(chunk));
      res.on('end', () => {
        try {
          resolve(JSON.parse(Buffer.concat(chunks).toString()));
        } catch {
          reject(new Error('Failed to parse response JSON'));
        }
      });
    });
    req.on('error', reject);
    if (options.body) req.write(options.body);
    req.end();
  });
}

function isLocalhostUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    if (parsed.hostname !== 'localhost' && parsed.hostname !== '127.0.0.1') return false;
    // Restrict to typical agent callback shape: short path, sane port range
    const port = parsed.port ? parseInt(parsed.port, 10) : 0;
    if (port < 1024 || port > 65535) return false;
    if (parsed.pathname.length > 64) return false;
    return true;
  } catch {
    return false;
  }
}

// Step 1 — redirect to Discord OAuth
authRouter.get('/discord', (req: Request, res: Response) => {
  console.log(`[auth] /discord hit — dashboard=${req.query['dashboard']}, ua=${req.headers['user-agent']?.slice(0,50)}`);

  const isDashboard = req.query['dashboard'] === '1';
  const rawCallback = req.query['callback'] as string | undefined;
  const callback = rawCallback && isLocalhostUrl(rawCallback) ? rawCallback : undefined;
  const nonce = crypto.randomBytes(24).toString('base64url');
  const sig = signNonce(nonce);
  // Nonce + HMAC signature travel in state — no session needed for CSRF protection.
  const state = Buffer.from(JSON.stringify({ dashboard: isDashboard, callback, nonce, sig })).toString('base64url');
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    response_type: 'code',
    scope: 'identify',
    state,
  });
  res.redirect(`${DISCORD_API}/oauth2/authorize?${params}`);
});

// Step 2 — Discord redirects here with code
authRouter.get('/discord/callback', async (req: Request, res: Response) => {
  console.log(`[auth] callback hit — code=${!!(req.query['code'])}, state=${!!(req.query['state'])}, secure=${req.secure}, proto=${req.headers['x-forwarded-proto']}`);
  try {
    const code = req.query['code'] as string | undefined;
    if (!code) return res.status(400).send('Missing code');

    // Decode state + verify CSRF nonce via HMAC (no session dependency)
    let isDashboard = false;
    let agentCallback: string | undefined;
    let stateNonce: string | undefined;
    let stateSig: string | undefined;
    try {
      const raw = req.query['state'] as string | undefined;
      if (raw) {
        const decoded = JSON.parse(Buffer.from(raw, 'base64url').toString()) as { dashboard?: boolean; callback?: string; nonce?: string; sig?: string };
        isDashboard = decoded.dashboard === true;
        if (decoded.callback && isLocalhostUrl(decoded.callback)) {
          agentCallback = decoded.callback;
        }
        stateNonce = decoded.nonce;
        stateSig = decoded.sig;
      }
    } catch { /* ignore malformed state */ }

    // Verify HMAC — session is NOT consulted, so this survives autoscale restarts
    if (!stateNonce || !stateSig || !verifyNonceSig(stateNonce, stateSig)) {
      // Legacy fallback: also accept old session-based nonce for in-flight requests
      const sessionNonce = req.session.oauthNonce;
      delete req.session.oauthNonce;
      if (!stateNonce || !sessionNonce || stateNonce !== sessionNonce) {
        console.warn('[auth] CSRF nonce mismatch — rejecting OAuth callback');
        return res.status(400).send('Invalid OAuth state. Please <a href="/auth/discord?dashboard=1">try again</a>.');
      }
    }

    // Exchange code for access token
    const body = new URLSearchParams({
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
      grant_type: 'authorization_code',
      code,
      redirect_uri: REDIRECT_URI,
    }).toString();

    const tokenData = await httpsRequest(`${DISCORD_API}/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    }) as { access_token?: string };

    if (!tokenData.access_token) return res.status(400).send('OAuth failed');

    // Fetch Discord user
    const user = await httpsRequest(`${DISCORD_API}/users/@me`, {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    }) as { id: string; username: string; avatar?: string };

    // Look up existing token_version (or insert new user with tv=1)
    const existing = await pool.query<{ id: number; token_version: number; is_banned: boolean }>(
      `SELECT id, token_version, is_banned FROM sc_tracker.users WHERE discord_id = $1`,
      [user.id]
    );

    if (existing.rows[0]?.is_banned) {
      console.warn(`[auth] banned user attempted login: ${user.id}`);
      return res.status(403).send('This account has been suspended.');
    }

    const tokenVersion = existing.rows[0]?.token_version ?? 1;
    const agentToken = generateToken(user.id, tokenVersion);
    const result = await pool.query<{ id: number }>(
      `INSERT INTO sc_tracker.users (discord_id, discord_username, discord_avatar, token, token_version)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (discord_id) DO UPDATE
         SET discord_username = EXCLUDED.discord_username,
             discord_avatar   = EXCLUDED.discord_avatar,
             token            = EXCLUDED.token,
             updated_at       = NOW()
       RETURNING id`,
      [user.id, user.username, user.avatar ?? null, agentToken, tokenVersion]
    );
    const userId: number = result.rows[0].id;

    if (isDashboard) {
      // Populate session and redirect to dashboard
      req.session.userId = userId;
      req.session.discordId = user.id;
      req.session.username = user.username;
      req.session.avatar = user.avatar ?? null;
      req.session.theme = req.session.theme ?? 'dark-purple';
      return req.session.save((err) => {
        if (err) return res.status(500).send('Session error');
        res.redirect('/tracker');
      });
    }

    // Agent flow — set web session so the dashboard redirect after auth lands correctly
    req.session.userId = userId;
    req.session.discordId = user.id;
    req.session.username = user.username;
    req.session.avatar = user.avatar ?? null;
    req.session.theme = req.session.theme ?? 'dark-purple';

    if (agentCallback) {
      return req.session.save((err) => {
        if (err) return res.status(500).send('Session error');
        res.redirect(`${agentCallback}?t=${encodeURIComponent(agentToken)}`);
      });
    }
    req.session.save((err) => {
      if (err) console.error('[auth] session save failed:', err);
    });
    res.render('token', { username: user.username, token: agentToken });
  } catch (err) {
    console.error('[auth] callback error:', err);
    res.status(500).send(`Auth error: ${(err as Error).message}`);
  }
});

// Agent calls this to verify its token
authRouter.get('/verify', async (req: Request, res: Response) => {
  const token = req.headers['authorization']?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token' });
  const payload = verifyToken(token);
  if (!payload) return res.status(401).json({ error: 'Invalid token' });
  const result = await pool.query<{ id: number; discord_username: string; token_version: number; is_banned: boolean }>(
    'SELECT id, discord_username, token_version, is_banned FROM sc_tracker.users WHERE discord_id = $1',
    [payload.discordId]
  );
  if (!result.rows[0]) return res.status(401).json({ error: 'User not found' });
  if (result.rows[0].is_banned) return res.status(403).json({ error: 'Account suspended' });
  if (result.rows[0].token_version !== payload.tv) {
    return res.status(401).json({ error: 'Token revoked — please re-link your agent' });
  }
  res.json({ userId: result.rows[0].id, username: result.rows[0].discord_username });
});

// Dashboard logout
authRouter.post('/logout', (req: Request, res: Response) => {
  req.session.destroy((err) => {
    if (err) console.error('[auth] session destroy failed:', err);
    res.redirect('/tracker');
  });
});

// Rotate the agent token — invalidates prior tokens for this user.
authRouter.post('/rotate-token', async (req: Request, res: Response) => {
  if (!req.session.userId || !req.session.discordId) {
    return res.status(401).send('Not logged in');
  }
  try {
    const result = await pool.query<{ token_version: number }>(
      `UPDATE sc_tracker.users
         SET token_version = token_version + 1, updated_at = NOW()
       WHERE id = $1
       RETURNING token_version`,
      [req.session.userId]
    );
    const tv = result.rows[0]?.token_version ?? 1;
    const newToken = generateToken(req.session.discordId, tv);
    await pool.query(`UPDATE sc_tracker.users SET token = $1 WHERE id = $2`, [newToken, req.session.userId]);
    // Active-session revocation: kick any agent currently connected with the
    // old token. They'll reconnect using the new one once the user pastes it.
    const kicked = revokeUserSockets(req.session.userId, 'Token rotated — please re-link your agent');
    if (kicked > 0) console.log(`[auth] rotate-token: kicked ${kicked} active socket(s) for user ${req.session.userId}`);
    res.render('token', { username: req.session.username ?? '', token: newToken });
  } catch (err) {
    console.error('[auth] token rotation failed:', err);
    res.status(500).send('Failed to rotate token');
  }
});
