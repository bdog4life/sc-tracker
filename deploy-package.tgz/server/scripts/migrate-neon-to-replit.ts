/**
 * One-shot migration: Neon PostgreSQL → Replit built-in PostgreSQL
 *
 * Run with:
 *   cd server && npx tsx scripts/migrate-neon-to-replit.ts
 *
 * Requires both NEON_DATABASE_URL and DATABASE_URL to be set.
 * Safe to re-run: clears Replit tables first (TRUNCATE … CASCADE), then
 * bulk-inserts all rows from Neon.
 */

import { Pool } from 'pg';

const NEON_URL    = process.env['NEON_DATABASE_URL'];
const REPLIT_URL  = process.env['DATABASE_URL'];

if (!NEON_URL)   throw new Error('NEON_DATABASE_URL is not set');
if (!REPLIT_URL) throw new Error('DATABASE_URL is not set');

const neon   = new Pool({ connectionString: NEON_URL,   ssl: { rejectUnauthorized: false }, max: 5 });
const replit = new Pool({ connectionString: REPLIT_URL, ssl: { rejectUnauthorized: false }, max: 5 });

function log(msg: string) {
  console.log(`[${new Date().toISOString()}] ${msg}`);
}

async function tableCount(pool: Pool, schema: string, table: string): Promise<number> {
  const r = await pool.query(`SELECT COUNT(*) AS n FROM ${schema}.${table}`);
  return parseInt(r.rows[0].n, 10);
}

async function ensureReplitSchema(): Promise<void> {
  log('Ensuring sc_tracker schema and all tables exist in Replit DB…');
  const rc = await replit.connect();
  try {
    await rc.query('BEGIN');
    await rc.query(`CREATE SCHEMA IF NOT EXISTS sc_tracker`);

    // Core tables (already exist in Replit dev DB)
    await rc.query(`CREATE TABLE IF NOT EXISTS sc_tracker.users (
      id SERIAL PRIMARY KEY, discord_id TEXT NOT NULL UNIQUE,
      discord_username TEXT NOT NULL, discord_avatar TEXT,
      token TEXT NOT NULL UNIQUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      is_banned BOOLEAN NOT NULL DEFAULT FALSE,
      token_version INTEGER NOT NULL DEFAULT 1,
      discord_webhook_url TEXT
    )`);
    await rc.query(`CREATE TABLE IF NOT EXISTS sc_tracker.sessions (
      id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES sc_tracker.users(id),
      character_name TEXT NOT NULL, game_version TEXT, game_branch TEXT,
      started_at TIMESTAMPTZ NOT NULL, ended_at TIMESTAMPTZ, duration_secs INTEGER
    )`);
    await rc.query(`CREATE TABLE IF NOT EXISTS sc_tracker.events (
      id SERIAL PRIMARY KEY, session_id INTEGER REFERENCES sc_tracker.sessions(id),
      user_id INTEGER NOT NULL REFERENCES sc_tracker.users(id),
      event_type TEXT NOT NULL, occurred_at TIMESTAMPTZ NOT NULL,
      payload JSONB NOT NULL DEFAULT '{}', parser_version INTEGER NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);
    await rc.query(`CREATE TABLE IF NOT EXISTS sc_tracker.discord_notifications (
      id SERIAL PRIMARY KEY, event_id INTEGER REFERENCES sc_tracker.events(id),
      channel_id TEXT NOT NULL, sent_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      message_preview TEXT
    )`);
    await rc.query(`CREATE TABLE IF NOT EXISTS sc_tracker.ships (
      id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES sc_tracker.users(id),
      entitlement_urn TEXT NOT NULL, display_name TEXT,
      claims_count INTEGER NOT NULL DEFAULT 0, last_claimed_at TIMESTAMPTZ,
      UNIQUE(user_id, entitlement_urn)
    )`);
    await rc.query(`CREATE TABLE IF NOT EXISTS sc_tracker.highlights (
      id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES sc_tracker.users(id),
      session_id INTEGER REFERENCES sc_tracker.sessions(id),
      type TEXT NOT NULL, severity TEXT NOT NULL DEFAULT 'minor',
      occurred_at TIMESTAMPTZ NOT NULL, payload JSONB NOT NULL DEFAULT '{}',
      dedup_key TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(user_id, type, dedup_key)
    )`);
    await rc.query(`CREATE TABLE IF NOT EXISTS sc_tracker.blueprints (
      id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES sc_tracker.users(id),
      raw_name TEXT NOT NULL, display_name TEXT, category TEXT, blueprint_id TEXT,
      first_received_at TIMESTAMPTZ NOT NULL, times_received INTEGER NOT NULL DEFAULT 1,
      UNIQUE(user_id, raw_name)
    )`);
    await rc.query(`CREATE TABLE IF NOT EXISTS sc_tracker.seasons (
      id SERIAL PRIMARY KEY, name TEXT NOT NULL, description TEXT,
      metric TEXT NOT NULL, started_at TIMESTAMPTZ NOT NULL,
      ended_at TIMESTAMPTZ, created_by INTEGER REFERENCES sc_tracker.users(id),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);

    // Session store
    await rc.query(`CREATE TABLE IF NOT EXISTS public.session (
      sid VARCHAR NOT NULL PRIMARY KEY, sess JSON NOT NULL, expire TIMESTAMPTZ NOT NULL
    )`);

    // Ensure late-added columns exist (ALTER TABLE … ADD COLUMN IF NOT EXISTS is idempotent)
    await rc.query(`ALTER TABLE sc_tracker.users ADD COLUMN IF NOT EXISTS is_banned BOOLEAN NOT NULL DEFAULT FALSE`);
    await rc.query(`ALTER TABLE sc_tracker.users ADD COLUMN IF NOT EXISTS token_version INTEGER NOT NULL DEFAULT 1`);
    await rc.query(`ALTER TABLE sc_tracker.users ADD COLUMN IF NOT EXISTS discord_webhook_url TEXT`);

    // Ensure unique constraint on events
    await rc.query(`
      DO $$ BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint
          WHERE conname = 'sc_tracker_events_user_event_time_unique'
            AND conrelid = 'sc_tracker.events'::regclass
        ) THEN
          ALTER TABLE sc_tracker.events
            ADD CONSTRAINT sc_tracker_events_user_event_time_unique
            UNIQUE (user_id, event_type, occurred_at);
        END IF;
      END $$
    `);

    await rc.query('COMMIT');
  } catch (e) {
    await rc.query('ROLLBACK');
    throw e;
  } finally {
    rc.release();
  }
  log('Schema ready.');
}

async function copyTable(opts: {
  schema: string;
  table: string;
  /** Column list to select / insert (explicit avoids serial default surprises) */
  columns: string[];
  /** Extra WHERE clause (without WHERE keyword), e.g. "id > 0" */
  where?: string;
  /** Batch size for INSERT … VALUES */
  batchSize?: number;
}): Promise<void> {
  const { schema, table, columns, where, batchSize = 500 } = opts;
  const qualified = `${schema}.${table}`;
  const colList   = columns.join(', ');
  const whereSql  = where ? ` WHERE ${where}` : '';

  const neonCount   = await tableCount(neon,   schema, table);
  log(`  ${qualified}: ${neonCount} rows in Neon`);

  if (neonCount === 0) {
    log(`  ${qualified}: nothing to copy — skipping`);
    return;
  }

  // Stream all rows from Neon
  const { rows } = await neon.query(`SELECT ${colList} FROM ${qualified}${whereSql} ORDER BY id`);

  // Bulk-insert in batches
  let inserted = 0;
  for (let i = 0; i < rows.length; i += batchSize) {
    const batch = rows.slice(i, i + batchSize);
    const placeholders = batch.map((_, ri) =>
      '(' + columns.map((_, ci) => `$${ri * columns.length + ci + 1}`).join(', ') + ')'
    ).join(', ');
    const values = batch.flatMap(row => columns.map(c => row[c]));

    await replit.query(
      `INSERT INTO ${qualified} (${colList}) VALUES ${placeholders} ON CONFLICT DO NOTHING`,
      values
    );
    inserted += batch.length;
    if (rows.length > batchSize) process.stdout.write(`\r    inserted ${inserted}/${rows.length}…`);
  }
  if (rows.length > batchSize) process.stdout.write('\n');

  const replitCount = await tableCount(replit, schema, table);
  log(`  ${qualified}: done — ${replitCount} rows now in Replit`);
}

async function resetSequence(schema: string, table: string, column = 'id'): Promise<void> {
  await replit.query(`
    SELECT setval(
      pg_get_serial_sequence('${schema}.${table}', '${column}'),
      COALESCE((SELECT MAX(${column}) FROM ${schema}.${table}), 0) + 1,
      false
    )
  `);
}

async function main(): Promise<void> {
  log('=== Neon → Replit migration starting ===');

  // 1. Create any missing tables in Replit
  await ensureReplitSchema();

  // 2. Truncate existing Replit data (dev stubs) in reverse FK order
  log('Truncating existing Replit sc_tracker data…');
  const rc = await replit.connect();
  try {
    await rc.query('BEGIN');
    await rc.query(`TRUNCATE sc_tracker.discord_notifications,
                              sc_tracker.highlights,
                              sc_tracker.blueprints,
                              sc_tracker.ships,
                              sc_tracker.events,
                              sc_tracker.sessions,
                              sc_tracker.seasons,
                              sc_tracker.users
                    RESTART IDENTITY CASCADE`);
    await rc.query('COMMIT');
  } catch (e) {
    await rc.query('ROLLBACK');
    throw e;
  } finally {
    rc.release();
  }
  log('Truncate complete.');

  // 3. Copy tables in FK-safe dependency order
  log('Copying tables from Neon…');

  await copyTable({
    schema: 'sc_tracker', table: 'users',
    columns: ['id','discord_id','discord_username','discord_avatar',
              'token','created_at','updated_at','is_banned','token_version',
              'discord_webhook_url'],
  });

  await copyTable({
    schema: 'sc_tracker', table: 'sessions',
    columns: ['id','user_id','character_name','game_version','game_branch',
              'started_at','ended_at','duration_secs'],
  });

  await copyTable({
    schema: 'sc_tracker', table: 'events',
    columns: ['id','session_id','user_id','event_type','occurred_at',
              'payload','parser_version','created_at'],
    batchSize: 200,
  });

  await copyTable({
    schema: 'sc_tracker', table: 'ships',
    columns: ['id','user_id','entitlement_urn','display_name',
              'claims_count','last_claimed_at'],
  });

  await copyTable({
    schema: 'sc_tracker', table: 'highlights',
    columns: ['id','user_id','session_id','type','severity',
              'occurred_at','payload','dedup_key','created_at'],
  });

  await copyTable({
    schema: 'sc_tracker', table: 'blueprints',
    columns: ['id','user_id','raw_name','display_name','category',
              'blueprint_id','first_received_at','times_received'],
  });

  await copyTable({
    schema: 'sc_tracker', table: 'seasons',
    columns: ['id','name','description','metric','started_at',
              'ended_at','created_by','created_at'],
  });

  await copyTable({
    schema: 'sc_tracker', table: 'discord_notifications',
    columns: ['id','event_id','channel_id','sent_at','message_preview'],
  });

  // 4. Copy public.session (connect-pg-simple session store)
  log('Copying public.session store…');
  const sessionExists = await neon.query(`
    SELECT EXISTS (
      SELECT 1 FROM information_schema.tables
      WHERE table_schema = 'public' AND table_name = 'session'
    ) AS exists
  `);
  if (sessionExists.rows[0].exists) {
    await replit.query(`
      CREATE TABLE IF NOT EXISTS public.session (
        sid    VARCHAR NOT NULL PRIMARY KEY,
        sess   JSON    NOT NULL,
        expire TIMESTAMPTZ NOT NULL
      )
    `);
    const { rows: sessions } = await neon.query(
      `SELECT sid, sess, expire FROM public.session WHERE expire > NOW()`
    );
    if (sessions.length > 0) {
      for (const s of sessions) {
        await replit.query(
          `INSERT INTO public.session (sid, sess, expire) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`,
          [s.sid, s.sess, s.expire]
        );
      }
      log(`  public.session: copied ${sessions.length} active session(s)`);
    } else {
      log('  public.session: no active sessions to copy');
    }
  } else {
    log('  public.session: table does not exist in Neon — skipping');
  }

  // 5. Reset all sequences so new inserts don't collide
  log('Resetting sequences…');
  for (const t of ['users','sessions','events','ships','highlights','blueprints','seasons','discord_notifications']) {
    await resetSequence('sc_tracker', t);
  }
  log('Sequences reset.');

  // 6. Final row counts
  log('=== Final row counts in Replit ===');
  for (const t of ['users','sessions','events','ships','highlights','blueprints','seasons','discord_notifications']) {
    const n = await tableCount(replit, 'sc_tracker', t);
    log(`  sc_tracker.${t}: ${n}`);
  }

  log('=== Migration complete ===');
  await neon.end();
  await replit.end();
}

main().catch(err => {
  console.error('[migration] FAILED:', err);
  process.exit(1);
});
